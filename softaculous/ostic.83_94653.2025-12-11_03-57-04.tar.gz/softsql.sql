-- Softaculous SQL Dump
-- http://www.softaculous.com
--
-- Host: localhost
-- Generation Time: December 11, 2025, 3:57 am
-- Server version: 10.6.23
-- PHP Version: 8.4.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apexvalu_osti455`
--

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_api_key`
--

CREATE TABLE `ostqr_api_key` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isactive` tinyint(1) NOT NULL DEFAULT 1,
  `ipaddr` varchar(64) NOT NULL,
  `apikey` varchar(255) NOT NULL,
  `can_create_tickets` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `can_exec_cron` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `apikey` (`apikey`),
  KEY `ipaddr` (`ipaddr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_attachment`
--

CREATE TABLE `ostqr_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) unsigned NOT NULL,
  `type` char(1) NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `inline` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `lang` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file-type` (`object_id`,`file_id`,`type`),
  UNIQUE KEY `file_object` (`file_id`,`object_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_attachment`
--

INSERT INTO `ostqr_attachment` VALUES
(1, 1, 'C', 2, NULL, 0, NULL),
(2, 8, 'T', 1, NULL, 1, NULL),
(3, 9, 'T', 1, NULL, 1, NULL),
(4, 10, 'T', 1, NULL, 1, NULL),
(5, 11, 'T', 1, NULL, 1, NULL),
(6, 12, 'T', 1, NULL, 1, NULL),
(7, 13, 'T', 1, NULL, 1, NULL),
(8, 14, 'T', 1, NULL, 1, NULL),
(9, 16, 'T', 1, NULL, 1, NULL),
(10, 17, 'T', 1, NULL, 1, NULL),
(11, 18, 'T', 1, NULL, 1, NULL),
(12, 19, 'T', 1, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_canned_response`
--

CREATE TABLE `ostqr_canned_response` (
  `canned_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `isenabled` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `response` text NOT NULL,
  `lang` varchar(16) NOT NULL DEFAULT 'en_US',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`canned_id`),
  UNIQUE KEY `title` (`title`),
  KEY `dept_id` (`dept_id`),
  KEY `active` (`isenabled`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_canned_response`
--

INSERT INTO `ostqr_canned_response` VALUES
(1, 0, 1, 'What is osTicket (sample)?', 'osTicket is a widely-used open source support ticket system, an\nattractive alternative to higher-cost and complex customer support\nsystems - simple, lightweight, reliable, open source, web-based and easy\nto setup and use.', 'en_US', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 0, 1, 'Sample (with variables)', 'Hi %{ticket.name.first},\n<br>\n<br>\nYour ticket #%{ticket.number} created on %{ticket.create_date} is in\n%{ticket.dept.name} department.', 'en_US', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_config`
--

CREATE TABLE `ostqr_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(64) NOT NULL,
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `namespace` (`namespace`,`key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_config`
--

INSERT INTO `ostqr_config` VALUES
(1, 'core', 'admin_email', 'hello@m.apexsinc.com', '2025-12-10 07:44:01'),
(2, 'core', 'helpdesk_url', 'https://support.apexsinc.com/', '2025-12-10 05:54:55'),
(3, 'core', 'helpdesk_title', 'APEXS Support Ticket System', '2025-12-10 06:08:55'),
(4, 'core', 'schema_signature', '5fb92bef17f3b603659e024c01cc7a59', '2025-12-10 05:54:55'),
(5, 'schedule.1', 'configuration', '{"holidays":[4]}', '2025-12-10 05:54:55'),
(6, 'core', 'time_format', 'hh:mm a', '2025-12-10 05:54:55'),
(7, 'core', 'date_format', 'MM/dd/y', '2025-12-10 05:54:55'),
(8, 'core', 'datetime_format', 'MM/dd/y h:mm a', '2025-12-10 05:54:55'),
(9, 'core', 'daydatetime_format', 'EEE, MMM d y h:mm a', '2025-12-10 05:54:55'),
(10, 'core', 'default_priority_id', '2', '2025-12-10 05:54:55'),
(11, 'core', 'enable_daylight_saving', '', '2025-12-10 05:54:55'),
(12, 'core', 'reply_separator', '-- reply above this line --', '2025-12-10 05:54:55'),
(13, 'core', 'isonline', '1', '2025-12-10 05:54:55'),
(14, 'core', 'staff_ip_binding', '0', '2025-12-10 06:53:01'),
(15, 'core', 'staff_max_logins', '4', '2025-12-10 05:54:55'),
(16, 'core', 'staff_login_timeout', '2', '2025-12-10 05:54:55'),
(17, 'core', 'staff_session_timeout', '30', '2025-12-10 05:54:55'),
(18, 'core', 'passwd_reset_period', '', '2025-12-10 05:54:55'),
(19, 'core', 'client_max_logins', '4', '2025-12-10 05:54:55'),
(20, 'core', 'client_login_timeout', '2', '2025-12-10 05:54:55'),
(21, 'core', 'client_session_timeout', '30', '2025-12-10 05:54:55'),
(22, 'core', 'max_page_size', '25', '2025-12-10 05:54:55'),
(23, 'core', 'max_open_tickets', '', '2025-12-10 05:54:55'),
(24, 'core', 'autolock_minutes', '3', '2025-12-10 05:54:55'),
(25, 'core', 'default_smtp_id', '0', '2025-12-10 07:44:01'),
(26, 'core', 'use_email_priority', '0', '2025-12-10 07:44:01'),
(27, 'core', 'enable_kb', '', '2025-12-10 05:54:55'),
(28, 'core', 'enable_premade', '1', '2025-12-10 05:54:55'),
(29, 'core', 'enable_captcha', '', '2025-12-10 05:54:55'),
(30, 'core', 'enable_auto_cron', '0', '2025-12-10 07:44:01'),
(31, 'core', 'enable_mail_polling', '0', '2025-12-10 07:44:01'),
(32, 'core', 'send_sys_errors', '0', '2025-12-10 09:20:53'),
(33, 'core', 'send_sql_errors', '1', '2025-12-10 05:54:55'),
(34, 'core', 'send_login_errors', '1', '2025-12-10 05:54:55'),
(35, 'core', 'save_email_headers', '1', '2025-12-10 05:54:55'),
(36, 'core', 'strip_quoted_reply', '1', '2025-12-10 05:54:55'),
(37, 'core', 'ticket_autoresponder', '1', '2025-12-10 09:20:53'),
(38, 'core', 'message_autoresponder', '0', '2025-12-10 09:21:20'),
(39, 'core', 'ticket_notice_active', '1', '2025-12-10 05:54:55'),
(40, 'core', 'ticket_alert_active', '1', '2025-12-10 05:54:55'),
(41, 'core', 'ticket_alert_admin', '1', '2025-12-10 05:54:55'),
(42, 'core', 'ticket_alert_dept_manager', '1', '2025-12-10 05:54:55'),
(43, 'core', 'ticket_alert_dept_members', '0', '2025-12-10 09:20:53'),
(44, 'core', 'message_alert_active', '1', '2025-12-10 05:54:55'),
(45, 'core', 'message_alert_laststaff', '1', '2025-12-10 05:54:55'),
(46, 'core', 'message_alert_assigned', '1', '2025-12-10 05:54:55'),
(47, 'core', 'message_alert_dept_manager', '0', '2025-12-10 09:20:53'),
(48, 'core', 'note_alert_active', '0', '2025-12-10 09:20:53'),
(49, 'core', 'note_alert_laststaff', '1', '2025-12-10 05:54:55'),
(50, 'core', 'note_alert_assigned', '1', '2025-12-10 05:54:55'),
(51, 'core', 'note_alert_dept_manager', '0', '2025-12-10 09:20:53'),
(52, 'core', 'transfer_alert_active', '0', '2025-12-10 09:20:53'),
(53, 'core', 'transfer_alert_assigned', '0', '2025-12-10 09:20:53'),
(54, 'core', 'transfer_alert_dept_manager', '1', '2025-12-10 05:54:55'),
(55, 'core', 'transfer_alert_dept_members', '0', '2025-12-10 09:20:53'),
(56, 'core', 'overdue_alert_active', '1', '2025-12-10 05:54:55'),
(57, 'core', 'overdue_alert_assigned', '1', '2025-12-10 05:54:55'),
(58, 'core', 'overdue_alert_dept_manager', '1', '2025-12-10 05:54:55'),
(59, 'core', 'overdue_alert_dept_members', '0', '2025-12-10 09:20:53'),
(60, 'core', 'assigned_alert_active', '1', '2025-12-10 05:54:55'),
(61, 'core', 'assigned_alert_staff', '1', '2025-12-10 05:54:55'),
(62, 'core', 'assigned_alert_team_lead', '0', '2025-12-10 09:20:53'),
(63, 'core', 'assigned_alert_team_members', '0', '2025-12-10 09:20:53'),
(64, 'core', 'auto_claim_tickets', '1', '2025-12-10 05:54:55'),
(65, 'core', 'auto_refer_closed', '1', '2025-12-10 05:54:55'),
(66, 'core', 'collaborator_ticket_visibility', '1', '2025-12-10 05:54:55'),
(67, 'core', 'require_topic_to_close', '', '2025-12-10 05:54:55'),
(68, 'core', 'show_related_tickets', '1', '2025-12-10 05:54:55'),
(69, 'core', 'show_assigned_tickets', '1', '2025-12-10 05:54:55'),
(70, 'core', 'show_answered_tickets', '', '2025-12-10 05:54:55'),
(71, 'core', 'hide_staff_name', '0', '2025-12-10 06:53:01'),
(72, 'core', 'disable_agent_collabs', '0', '2025-12-10 06:53:01'),
(73, 'core', 'overlimit_notice_active', '0', '2025-12-10 09:21:12'),
(74, 'core', 'email_attachments', '1', '2025-12-10 05:54:55'),
(75, 'core', 'ticket_number_format', '######', '2025-12-10 05:54:55'),
(76, 'core', 'ticket_sequence_id', '', '2025-12-10 05:54:55'),
(77, 'core', 'queue_bucket_counts', '', '2025-12-10 05:54:55'),
(78, 'core', 'allow_external_images', '', '2025-12-10 05:54:55'),
(79, 'core', 'task_number_format', '#', '2025-12-10 05:54:55'),
(80, 'core', 'task_sequence_id', '2', '2025-12-10 05:54:55'),
(81, 'core', 'log_level', '2', '2025-12-10 05:54:55'),
(82, 'core', 'log_graceperiod', '12', '2025-12-10 05:54:55'),
(83, 'core', 'client_registration', 'public', '2025-12-10 05:54:55'),
(84, 'core', 'default_ticket_queue', '1', '2025-12-10 05:54:55'),
(85, 'core', 'embedded_domain_whitelist', 'youtube.com, dailymotion.com, vimeo.com, player.vimeo.com, web.microsoftstream.com', '2025-12-10 05:54:55'),
(86, 'core', 'max_file_size', '524288', '2025-12-10 06:57:55'),
(87, 'core', 'landing_page_id', '1', '2025-12-10 05:54:55'),
(88, 'core', 'thank-you_page_id', '2', '2025-12-10 05:54:55'),
(89, 'core', 'offline_page_id', '3', '2025-12-10 05:54:55'),
(90, 'core', 'system_language', 'en_US', '2025-12-10 05:54:55'),
(91, 'mysqlsearch', 'reindex', '0', '2025-12-10 06:00:04'),
(92, 'core', 'default_email_id', '1', '2025-12-10 05:54:55'),
(93, 'core', 'alert_email_id', '2', '2025-12-10 05:54:55'),
(94, 'core', 'default_dept_id', '1', '2025-12-10 05:54:55'),
(95, 'core', 'default_sla_id', '1', '2025-12-10 05:54:55'),
(96, 'core', 'schedule_id', '1', '2025-12-10 05:54:55'),
(97, 'core', 'default_template_id', '1', '2025-12-10 05:54:55'),
(98, 'core', 'default_timezone', 'Asia/Manila', '2025-12-10 06:42:29'),
(99, 'core', 'default_storage_bk', 'D', '2025-12-10 06:08:54'),
(100, 'core', 'force_https', 'on', '2025-12-10 06:08:55'),
(101, 'core', 'date_formats', '', '2025-12-10 06:08:55'),
(102, 'core', 'default_locale', '', '2025-12-10 06:08:55'),
(103, 'core', 'secondary_langs', '', '2025-12-10 06:08:55'),
(104, 'core', 'enable_avatars', '1', '2025-12-10 06:08:55'),
(105, 'core', 'enable_richtext', '1', '2025-12-10 06:08:55'),
(106, 'core', 'files_req_auth', '1', '2025-12-10 06:08:55'),
(107, 'core', 'allow_iframes', '', '2025-12-10 06:08:55'),
(108, 'core', 'acl', '', '2025-12-10 06:08:55'),
(109, 'core', 'acl_backend', '0', '2025-12-10 06:42:29'),
(110, 'core', 'agent_passwd_policy', ' ', '2025-12-10 06:53:01'),
(111, 'core', 'allow_pw_reset', '1', '2025-12-10 06:53:01'),
(112, 'core', 'pw_reset_window', '30', '2025-12-10 06:53:01'),
(113, 'core', 'require_agent_2fa', '0', '2025-12-10 06:53:37'),
(114, 'core', 'agent_name_format', 'full', '2025-12-10 06:53:01'),
(115, 'core', 'agent_avatar', 'local.ateam', '2025-12-10 06:54:18'),
(116, 'core', 'client_logo_id', '', '2025-12-10 06:56:46'),
(117, 'core', 'staff_logo_id', '', '2025-12-10 06:56:46'),
(118, 'core', 'staff_backdrop_id', '', '2025-12-10 06:56:46'),
(119, 'core', 'verify_email_addrs', '1', '2025-12-10 07:44:01'),
(120, 'core', 'accept_unregistered_email', '1', '2025-12-10 07:44:01'),
(121, 'core', 'add_email_collabs', '1', '2025-12-10 07:44:01'),
(122, 'staff.2', 'datetime_format', '', '2025-12-10 07:58:58'),
(123, 'staff.2', 'default_from_name', 'email', '2025-12-10 07:58:58'),
(124, 'staff.2', 'default_2fa', '', '2025-12-10 07:58:58'),
(125, 'staff.2', 'thread_view_order', '', '2025-12-10 07:58:58'),
(126, 'staff.2', 'default_ticket_queue_id', '0', '2025-12-10 07:58:58'),
(127, 'staff.2', 'reply_redirect', 'Queue', '2025-12-10 07:59:43'),
(128, 'staff.2', 'img_att_view', 'download', '2025-12-10 07:58:58'),
(129, 'staff.2', 'editor_spacing', 'double', '2025-12-10 07:58:58'),
(130, 'core', 'message_autoresponder_collabs', '1', '2025-12-10 09:20:53'),
(131, 'core', 'ticket_alert_acct_manager', '0', '2025-12-10 09:21:12'),
(132, 'core', 'message_alert_acct_manager', '0', '2025-12-10 09:21:12'),
(133, 'core', 'client_passwd_policy', ' ', '2025-12-10 09:42:53'),
(134, 'core', 'clients_only', '0', '2025-12-10 09:43:07'),
(135, 'core', 'client_verify_email', '1', '2025-12-10 09:43:07'),
(136, 'core', 'allow_auth_tokens', '1', '2025-12-10 09:42:53'),
(137, 'core', 'client_name_format', 'original', '2025-12-10 09:42:53'),
(138, 'core', 'client_avatar', 'gravatar.mm', '2025-12-10 09:42:53');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_content`
--

CREATE TABLE `ostqr_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `type` varchar(32) NOT NULL DEFAULT 'other',
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_content`
--

INSERT INTO `ostqr_content` VALUES
(1, 1, 'landing', 'Landing', '<h1>Welcome to the Support Center</h1> <p> In order to streamline support requests and better serve you, we utilize a support ticket system. Every support request is assigned a unique ticket number which you can use to track the progress and responses online. For your reference we provide complete archives and history of all your support requests. A valid email address is required to submit a ticket. </p>', 'The Landing Page refers to the content of the Customer Portal''s initial view. The template modifies the content seen above the two links <strong>Open a New Ticket</strong> and <strong>Check Ticket Status</strong>.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 1, 'thank-you', 'Thank You', '<div>%{ticket.name},\n<br>\n<br>\nThank you for contacting us.\n<br>\n<br>\nA support ticket request has been created and a representative will be\ngetting back to you shortly if necessary.</p>\n<br>\n<br>\nSupport Team\n</div>', 'This template defines the content displayed on the Thank-You page after a\nClient submits a new ticket in the Client Portal.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(3, 1, 'offline', 'Offline', '<div><h1>\n<span style="font-size: medium">Support Ticket System Offline</span>\n</h1>\n<p>Thank you for your interest in contacting us.</p>\n<p>Our helpdesk is offline at the moment, please check back at a later\ntime.</p>\n</div>', 'The Offline Page appears in the Customer Portal when the Help Desk is offline.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(4, 1, 'registration-staff', 'Welcome to osTicket', '<h3><strong>Hi %{recipient.name.first},</strong></h3> <div> We''ve created an account for you at our help desk at %{url}.<br /> <br /> Please follow the link below to confirm your account and gain access to your tickets.<br /> <br /> <a href="%{link}">%{link}</a><br /> <br /> <em style="font-size: small">Your friendly Customer Support System<br /> %{company.name}</em> </div>', 'This template defines the initial email (optional) sent to Agents when an account is created on their behalf.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(5, 1, 'pwreset-staff', 'osTicket Staff Password Reset', '<h3><strong>Hi %{staff.name.first},</strong></h3> <div> A password reset request has been submitted on your behalf for the helpdesk at %{url}.<br /> <br /> If you feel that this has been done in error, delete and disregard this email. Your account is still secure and no one has been given access to it. It is not locked and your password has not been reset. Someone could have mistakenly entered your email address.<br /> <br /> Follow the link below to login to the help desk and change your password.<br /> <br /> <a href="%{link}">%{link}</a><br /> <br /> <em style="font-size: small">Your friendly Customer Support System</em> <br /> ', 'This template defines the email sent to Staff who select the <strong>Forgot My Password</strong> link on the Staff Control Panel Log In page.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(6, 1, 'banner-staff', 'Authentication Required', '', 'This is the initial message and banner shown on the Staff Log In page. The first input field refers to the red-formatted text that appears at the top. The latter textarea is for the banner content which should serve as a disclaimer.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(7, 1, 'registration-client', 'Welcome to %{company.name}', '<h3><strong>Hi %{recipient.name.first},</strong></h3> <div> We''ve created an account for you at our help desk at %{url}.<br /> <br /> Please follow the link below to confirm your account and gain access to your tickets.<br /> <br /> <a href="%{link}">%{link}</a><br /> <br /> <em style="font-size: small">Your friendly Customer Support System <br /> %{company.name}</em> </div>', 'This template defines the email sent to Clients when their account has been created in the Client Portal or by an Agent on their behalf. This email serves as an email address verification. Please use %{link} somewhere in the body.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(8, 1, 'pwreset-client', '%{company.name} Help Desk Access', '<h3><strong>Hi %{user.name.first},</strong></h3> <div> A password reset request has been submitted on your behalf for the helpdesk at %{url}.<br /> <br /> If you feel that this has been done in error, delete and disregard this email. Your account is still secure and no one has been given access to it. It is not locked and your password has not been reset. Someone could have mistakenly entered your email address.<br /> <br /> Follow the link below to login to the help desk and change your password.<br /> <br /> <a href="%{link}">%{link}</a><br /> <br /> <em style="font-size: small">Your friendly Customer Support System <br /> %{company.name}</em> </div>', 'This template defines the email sent to Clients who select the <strong>Forgot My Password</strong> link on the Client Log In page.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(9, 1, 'banner-client', 'Sign in to %{company.name}', 'To better serve you, we encourage our Clients to register for an account.', 'This composes the header on the Client Log In page. It can be useful to inform your Clients about your log in and registration policies.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(10, 1, 'registration-confirm', 'Account registration', '<div><strong>Thanks for registering for an account.</strong><br/> <br /> We''ve just sent you an email to the address you entered. Please follow the link in the email to confirm your account and gain access to your tickets. </div>', 'This templates defines the page shown to Clients after completing the registration form. The template should mention that the system is sending them an email confirmation link and what is the next step in the registration process.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(11, 1, 'registration-thanks', 'Account Confirmed!', '<div> <strong>Thanks for registering for an account.</strong><br /> <br /> You''ve confirmed your email address and successfully activated your account. You may proceed to open a new ticket or manage existing tickets.<br /> <br /> <em>Your friendly support center</em><br /> %{company.name} </div>', 'This template defines the content displayed after Clients successfully register by confirming their account. This page should inform the user that registration is complete and that the Client can now submit a ticket or access existing tickets.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(12, 1, 'access-link', 'Ticket [#%{ticket.number}] Access Link', '<h3><strong>Hi %{recipient.name.first},</strong></h3> <div> An access link request for ticket #%{ticket.number} has been submitted on your behalf for the helpdesk at %{url}.<br /> <br /> Follow the link below to check the status of the ticket #%{ticket.number}.<br /> <br /> <a href="%{recipient.ticket_link}">%{recipient.ticket_link}</a><br /> <br /> If you <strong>did not</strong> make the request, please delete and disregard this email. Your account is still secure and no one has been given access to the ticket. Someone could have mistakenly entered your email address.<br /> <br /> --<br /> %{company.name} </div>', 'This template defines the notification for Clients that an access link was sent to their email. The ticket number and email address trigger the access link.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(13, 1, 'email2fa-staff', 'osTicket Two Factor Authentication', '<h3><strong>Hi %{staff.name.first},</strong></h3> <div> You have just logged into for the helpdesk at %{url}.<br /> <br /> Use the verification code below to finish logging into the helpdesk.<br /> <br /> %{otp}<br /> <br /> <em style="font-size: small">Your friendly Customer Support System</em> <br /> ', 'This template defines the email sent to Staff who use Email for Two Factor Authentication', '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_department`
--

CREATE TABLE `ostqr_department` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT NULL,
  `tpl_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sla_id` int(10) unsigned NOT NULL DEFAULT 0,
  `schedule_id` int(10) unsigned NOT NULL DEFAULT 0,
  `email_id` int(10) unsigned NOT NULL DEFAULT 0,
  `autoresp_email_id` int(10) unsigned NOT NULL DEFAULT 0,
  `manager_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(128) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `ispublic` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `group_membership` tinyint(1) NOT NULL DEFAULT 0,
  `ticket_auto_response` tinyint(1) NOT NULL DEFAULT 1,
  `message_auto_response` tinyint(1) NOT NULL DEFAULT 0,
  `path` varchar(128) NOT NULL DEFAULT '/',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`pid`),
  KEY `manager_id` (`manager_id`),
  KEY `autoresp_email_id` (`autoresp_email_id`),
  KEY `tpl_id` (`tpl_id`),
  KEY `flags` (`flags`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_department`
--

INSERT INTO `ostqr_department` VALUES
(1, NULL, 0, 0, 0, 0, 0, 0, 4, 'Support', 'Support Department', 1, 1, 1, 1, '/1/', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, NULL, 0, 1, 0, 0, 0, 0, 4, 'Sales', 'Sales and Customer Retention', 1, 1, 1, 1, '/2/', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(3, NULL, 0, 0, 0, 0, 0, 0, 4, 'Maintenance', 'Maintenance Department', 1, 0, 1, 1, '/3/', '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_draft`
--

CREATE TABLE `ostqr_draft` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) unsigned NOT NULL,
  `namespace` varchar(32) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `extra` text DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`),
  KEY `namespace` (`namespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_email`
--

CREATE TABLE `ostqr_email` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `noautoresp` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `priority_id` int(11) unsigned NOT NULL DEFAULT 2,
  `dept_id` int(11) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(11) unsigned NOT NULL DEFAULT 0,
  `email` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`email_id`),
  UNIQUE KEY `email` (`email`),
  KEY `priority_id` (`priority_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_email`
--

INSERT INTO `ostqr_email` VALUES
(1, 0, 2, 1, 0, 'system@apexsinc.com', 'System', NULL, '2025-12-10 05:54:55', '2025-12-10 07:51:43'),
(2, 0, 2, 1, 0, 'alerts@apexsinc.com', 'APEXS Alerts', NULL, '2025-12-10 05:54:55', '2025-12-10 06:43:34'),
(3, 0, 2, 1, 0, 'noreply@apexsinc.com', 'noreply', NULL, '2025-12-10 05:54:55', '2025-12-10 06:43:07'),
(4, 0, 2, 0, 0, 'hello@apexsinc.com', 'hello', NULL, '2025-12-10 07:13:33', '2025-12-10 07:13:33');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_email_account`
--

CREATE TABLE `ostqr_email_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email_id` int(11) unsigned NOT NULL,
  `type` enum('mailbox','smtp') NOT NULL DEFAULT 'mailbox',
  `auth_bk` varchar(128) NOT NULL,
  `auth_id` varchar(16) DEFAULT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `host` varchar(128) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL,
  `folder` varchar(255) DEFAULT NULL,
  `protocol` enum('IMAP','POP','SMTP','OTHER') NOT NULL DEFAULT 'OTHER',
  `encryption` enum('NONE','AUTO','SSL') NOT NULL DEFAULT 'AUTO',
  `fetchfreq` tinyint(3) unsigned NOT NULL DEFAULT 5,
  `fetchmax` tinyint(4) unsigned DEFAULT 30,
  `postfetch` enum('archive','delete','nothing') NOT NULL DEFAULT 'nothing',
  `archivefolder` varchar(255) DEFAULT NULL,
  `allow_spoofing` tinyint(1) unsigned DEFAULT 0,
  `num_errors` int(11) unsigned NOT NULL DEFAULT 0,
  `last_error_msg` tinytext DEFAULT NULL,
  `last_error` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `email_id` (`email_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_email_account`
--

INSERT INTO `ostqr_email_account` VALUES
(1, 3, 'mailbox', '', NULL, 0, '', 0, NULL, 'OTHER', 'AUTO', 5, 30, 'nothing', NULL, 0, 0, NULL, NULL, NULL, '2025-12-10 06:43:07', '2025-12-10 06:43:07'),
(2, 3, 'smtp', 'mailbox', NULL, 0, '', 0, NULL, 'SMTP', 'AUTO', 5, 30, 'nothing', NULL, 0, 0, NULL, NULL, NULL, '2025-12-10 06:43:07', '2025-12-10 06:43:07'),
(3, 2, 'mailbox', '', NULL, 0, '', 0, NULL, 'OTHER', 'AUTO', 5, 30, 'nothing', NULL, 0, 0, NULL, NULL, NULL, '2025-12-10 06:43:34', '2025-12-10 06:43:34'),
(4, 2, 'smtp', 'mailbox', NULL, 0, '', 0, NULL, 'SMTP', 'AUTO', 5, 30, 'nothing', NULL, 0, 0, NULL, NULL, NULL, '2025-12-10 06:43:34', '2025-12-10 06:43:34'),
(5, 1, 'mailbox', '', NULL, 0, '', 0, NULL, 'OTHER', 'AUTO', 5, 30, 'nothing', NULL, 0, 0, NULL, NULL, NULL, '2025-12-10 07:51:43', '2025-12-10 07:51:43'),
(6, 1, 'smtp', 'mailbox', NULL, 0, '', 0, NULL, 'SMTP', 'AUTO', 5, 30, 'nothing', NULL, 0, 0, NULL, NULL, NULL, '2025-12-10 07:51:43', '2025-12-10 07:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_email_template`
--

CREATE TABLE `ostqr_email_template` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tpl_id` int(11) unsigned NOT NULL,
  `code_name` varchar(32) NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_lookup` (`tpl_id`,`code_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_email_template`
--

INSERT INTO `ostqr_email_template` VALUES
(1, 1, 'ticket.autoresp', 'Support Ticket Opened [#%{ticket.number}]', '<h3><strong>Dear %{recipient.name.first},</strong></h3> <p>A request for support has been created and assigned #%{ticket.number}. A representative will follow-up with you as soon as possible. You can <a href="%%7Brecipient.ticket_link%7D">view this ticket''s progress online</a>. </p> <br /> <div style="color:rgb(127, 127, 127)">Your %{company.name} Team, <br /> %{signature} </div> <hr /><div style="color:rgb(127, 127, 127);font-size:small"><em>If you wish to provide additional comments or information regarding the issue, please reply to this email or <a href="%%7Brecipient.ticket_link%7D"><span style="color:rgb(84, 141, 212)">login to your account</span></a> for a complete archive of your support requests.</em></div>', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 1, 'ticket.autoreply', 'Re: %{ticket.subject} [#%{ticket.number}]', '<h3><strong>Dear %{recipient.name.first},</strong></h3> A request for support has been created and assigned ticket <a href="%%7Brecipient.ticket_link%7D">#%{ticket.number}</a> with the following automatic reply <br /><br /> Topic: <strong>%{ticket.topic.name}</strong> <br /> Subject: <strong>%{ticket.subject}</strong> <br /><br /> %{response} <br /><br /><div style="color:rgb(127, 127, 127)">Your %{company.name} Team,<br /> %{signature}</div> <hr /><div style="color:rgb(127, 127, 127);font-size:small"><em>We hope this response has sufficiently answered your questions. If you wish to provide additional comments or information, please reply to this email or <a href="%%7Brecipient.ticket_link%7D"><span style="color:rgb(84, 141, 212)">login to your account</span></a> for a complete archive of your support requests.</em></div>', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(3, 1, 'message.autoresp', 'Message Confirmation', '<h3><strong>Dear %{recipient.name.first},</strong></h3> Your reply to support request <a href="%%7Brecipient.ticket_link%7D">#%{ticket.number}</a> has been noted <br /><br /> <div style="color:rgb(127, 127, 127)">Your %{company.name} Team,<br /> %{signature} </div> <hr /><div style="color:rgb(127, 127, 127);font-size:small;text-align:center"><em>You can view the support request progress <a href="%%7Brecipient.ticket_link%7D">online here</a></em> </div>', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(4, 1, 'ticket.notice', '%{ticket.subject} [#%{ticket.number}]', '<h3><strong>Dear %{recipient.name.first},</strong></h3> Our customer care team has created a ticket, <a href="%%7Brecipient.ticket_link%7D">#%{ticket.number}</a> on your behalf, with the following details and summary: <br /><br /> Topic: <strong>%{ticket.topic.name}</strong> <br /> Subject: <strong>%{ticket.subject}</strong> <br /><br /> %{message} <br /><br /> %{response} <br /><br /> If need be, a representative will follow-up with you as soon as possible. You can also <a href="%%7Brecipient.ticket_link%7D">view this ticket''s progress online</a>. <br /><br /> <div style="color:rgb(127, 127, 127)">Your %{company.name} Team,<br /> %{signature}</div> <hr /><div style="color:rgb(127, 127, 127);font-size:small"><em>If you wish to provide additional comments or information regarding the issue, please reply to this email or <a href="%%7Brecipient.ticket_link%7D"><span style="color:rgb(84, 141, 212)">login to your account</span></a> for a complete archive of your support requests.</em></div>', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(5, 1, 'ticket.overlimit', 'Open Tickets Limit Reached', '<h3><strong>Dear %{ticket.name.first},</strong></h3> You have reached the maximum number of open tickets allowed. To be able to open another ticket, one of your pending tickets must be closed. To update or add comments to an open ticket simply <a href="%%7Burl%7D/tickets.php?e=%%7Bticket.email%7D">login to our helpdesk</a>. <br /><br /> Thank you,<br /> Support Ticket System', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(6, 1, 'ticket.reply', 'Re: %{ticket.subject} [#%{ticket.number}]', '<h3><strong>Dear %{recipient.name.first},</strong></h3> %{response} <br /><br /> <div style="color:rgb(127, 127, 127)">Your %{company.name} Team,<br /> %{signature} </div> <hr /><div style="color:rgb(127, 127, 127);font-size:small;text-align:center"><em>We hope this response has sufficiently answered your questions. If not, please do not send another email. Instead, reply to this email or <a href="%%7Brecipient.ticket_link%7D" style="color:rgb(84, 141, 212)">login to your account</a> for a complete archive of all your support requests and responses.</em></div>', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(7, 1, 'ticket.activity.notice', 'Re: %{ticket.subject} [#%{ticket.number}]', '<h3><strong>Dear %{recipient.name.first},</strong></h3> <div><em>%{poster.name}</em> just logged a message to a ticket in which you participate. </div> <br /> %{message} <br /><br /><hr /> <div style="color:rgb(127, 127, 127);font-size:small;text-align:center"><em>You''re getting this email because you are a collaborator on ticket <a href="%%7Brecipient.ticket_link%7D" style="color:rgb(84, 141, 212)">#%{ticket.number}</a>. To participate, simply reply to this email or <a href="%%7Brecipient.ticket_link%7D" style="color:rgb(84, 141, 212)">click here</a> for a complete archive of the ticket thread.</em> </div>', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(8, 1, 'ticket.alert', 'New Ticket Alert', '<h2>Hi %{recipient.name},</h2> New ticket #%{ticket.number} created <br /><br /><table><tbody><tr><td><strong>From</strong>: </td> <td>%{ticket.name} </td> </tr><tr><td><strong>Department</strong>: </td> <td>%{ticket.dept.name} </td> </tr></tbody></table><br /> %{message} <br /><br /><hr /><div>To view or respond to the ticket, please <a href="%%7Bticket.staff_link%7D">login</a> to the support ticket system</div> <em style="font-size:small">Your friendly Customer Support System</em> <br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(9, 1, 'message.alert', 'New Message Alert', '<h3><strong>Hi %{recipient.name},</strong></h3> New message appended to ticket <a href="%%7Bticket.staff_link%7D">#%{ticket.number}</a> <br /><br /><table><tbody><tr><td><strong>From</strong>: </td> <td>%{poster.name} </td> </tr><tr><td><strong>Department</strong>: </td> <td>%{ticket.dept.name} </td> </tr></tbody></table><br /> %{message} <br /><br /><hr /><div>To view or respond to the ticket, please <a href="%%7Bticket.staff_link%7D"><span style="color:rgb(84, 141, 212)">login</span></a> to the support ticket system</div> <em style="color:rgb(127,127,127);font-size:small">Your friendly Customer Support System</em><br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(10, 1, 'note.alert', 'New Internal Activity Alert', '<h3><strong>Hi %{recipient.name},</strong></h3> An agent has logged activity on ticket <a href="%%7Bticket.staff_link%7D">#%{ticket.number}</a> <br /><br /><table><tbody><tr><td><strong>From</strong>: </td> <td>%{note.poster} </td> </tr><tr><td><strong>Title</strong>: </td> <td>%{note.title} </td> </tr></tbody></table><br /> %{note.message} <br /><br /><hr /> To view/respond to the ticket, please <a href="%%7Bticket.staff_link%7D">login</a> to the support ticket system <br /><br /><em style="font-size:small">Your friendly Customer Support System</em> <br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(11, 1, 'assigned.alert', 'Ticket Assigned to you', '<h3><strong>Hi %{assignee.name.first},</strong></h3> Ticket <a href="%%7Bticket.staff_link%7D">#%{ticket.number}</a> has been assigned to you by %{assigner.name.short} <br /><br /><table><tbody><tr><td><strong>From</strong>: </td> <td>%{ticket.name} </td> </tr><tr><td><strong>Subject</strong>: </td> <td>%{ticket.subject} </td> </tr></tbody></table><br /> %{comments} <br /><br /><hr /><div>To view/respond to the ticket, please <a href="%%7Bticket.staff_link%7D"><span style="color:rgb(84, 141, 212)">login</span></a> to the support ticket system</div> <em style="font-size:small">Your friendly Customer Support System</em> <br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(12, 1, 'transfer.alert', 'Ticket #%{ticket.number} transfer - %{ticket.dept.name}', '<h3>Hi %{recipient.name},</h3> Ticket <a href="%%7Bticket.staff_link%7D">#%{ticket.number}</a> has been transferred to the %{ticket.dept.name} department by <strong>%{staff.name.short}</strong> <br /><br /> <blockquote>%{comments} </blockquote> <hr /><div>To view or respond to the ticket, please <a href="%%7Bticket.staff_link%7D">login</a> to the support ticket system. </div> <em style="font-size:small">Your friendly Customer Support System</em> <br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(13, 1, 'ticket.overdue', 'Stale Ticket Alert', '<h3><strong>Hi %{recipient.name}</strong>,</h3> A ticket, <a href="%%7Bticket.staff_link%7D">#%{ticket.number}</a> is seriously overdue. <br /><br /> We should all work hard to guarantee that all tickets are being addressed in a timely manner. <br /><br /> Signed,<br /> %{ticket.dept.manager.name} <hr /><div>To view or respond to the ticket, please <a href="%%7Bticket.staff_link%7D"><span style="color:rgb(84, 141, 212)">login</span></a> to the support ticket system. You''re receiving this notice because the ticket is assigned directly to you or to a team or department of which you''re a member.</div> <em style="font-size:small">Your friendly <span style="font-size:smaller">(although with limited patience)</span> Customer Support System</em><br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(14, 1, 'task.alert', 'New Task Alert', '<h2>Hi %{recipient.name},</h2> New task <a href="%%7Btask.staff_link%7D">#%{task.number}</a> created <br /><br /><table><tbody><tr><td><strong>Department</strong>: </td> <td>%{task.dept.name} </td> </tr></tbody></table><br /> %{task.description} <br /><br /><hr /><div>To view or respond to the task, please <a href="%%7Btask.staff_link%7D">login</a> to the support system</div> <em style="font-size:small">Your friendly Customer Support System</em> <br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(15, 1, 'task.activity.notice', 'Re: %{task.title} [#%{task.number}]', '<h3><strong>Dear %{recipient.name.first},</strong></h3> <div><em>%{poster.name}</em> just logged a message to a task in which you participate. </div> <br /> %{message} <br /><br /><hr /> <div style="color:rgb(127, 127, 127);font-size:small;text-align:center"><em>You''re getting this email because you are a collaborator on task #%{task.number}. To participate, simply reply to this email.</em> </div>', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(16, 1, 'task.activity.alert', 'Task Activity [#%{task.number}] - %{activity.title}', '<h3><strong>Hi %{recipient.name},</strong></h3> Task <a href="%%7Btask.staff_link%7D">#%{task.number}</a> updated: %{activity.description} <br /><br /> %{message} <br /><br /><hr /><div>To view or respond to the task, please <a href="%%7Btask.staff_link%7D"><span style="color:rgb(84, 141, 212)">login</span></a> to the support system</div> <em style="color:rgb(127,127,127);font-size:small">Your friendly Customer Support System</em><br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(17, 1, 'task.assignment.alert', 'Task Assigned to you', '<h3><strong>Hi %{assignee.name.first},</strong></h3> Task <a href="%%7Btask.staff_link%7D">#%{task.number}</a> has been assigned to you by %{assigner.name.short} <br /><br /> %{comments} <br /><br /><hr /><div>To view/respond to the task, please <a href="%%7Btask.staff_link%7D"><span style="color:rgb(84, 141, 212)">login</span></a> to the support system</div> <em style="font-size:small">Your friendly Customer Support System</em> <br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(18, 1, 'task.transfer.alert', 'Task #%{task.number} transfer - %{task.dept.name}', '<h3>Hi %{recipient.name},</h3> Task <a href="%%7Btask.staff_link%7D">#%{task.number}</a> has been transferred to the %{task.dept.name} department by <strong>%{staff.name.short}</strong> <br /><br /> <blockquote>%{comments} </blockquote> <hr /><div>To view or respond to the task, please <a href="%%7Btask.staff_link%7D">login</a> to the support system. </div> <em style="font-size:small">Your friendly Customer Support System</em> <br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(19, 1, 'task.overdue.alert', 'Stale Task Alert', '<h3><strong>Hi %{recipient.name}</strong>,</h3> A task, <a href="%%7Btask.staff_link%7D">#%{task.number}</a> is seriously overdue. <br /><br /> We should all work hard to guarantee that all tasks are being addressed in a timely manner. <br /><br /> Signed,<br /> %{task.dept.manager.name} <hr /><div>To view or respond to the task, please <a href="%%7Btask.staff_link%7D"><span style="color:rgb(84, 141, 212)">login</span></a> to the support system. You''re receiving this notice because the task is assigned directly to you or to a team or department of which you''re a member.</div> <em style="font-size:small">Your friendly <span style="font-size:smaller">(although with limited patience)</span> Customer Support System</em><br />', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_email_template_group`
--

CREATE TABLE `ostqr_email_template_group` (
  `tpl_id` int(11) NOT NULL AUTO_INCREMENT,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `name` varchar(32) NOT NULL DEFAULT '',
  `lang` varchar(16) NOT NULL DEFAULT 'en_US',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`tpl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_email_template_group`
--

INSERT INTO `ostqr_email_template_group` VALUES
(1, 1, 'APEXS Default Template (HTML)', 'en_US', '<p>Default osTicket templates</p>', '2025-12-10 05:54:55', '2025-12-10 09:22:03');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_event`
--

CREATE TABLE `ostqr_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_event`
--

INSERT INTO `ostqr_event` VALUES
(1, 'created', NULL),
(2, 'closed', NULL),
(3, 'reopened', NULL),
(4, 'assigned', NULL),
(5, 'released', NULL),
(6, 'transferred', NULL),
(7, 'referred', NULL),
(8, 'overdue', NULL),
(9, 'edited', NULL),
(10, 'viewed', NULL),
(11, 'error', NULL),
(12, 'collab', NULL),
(13, 'resent', NULL),
(14, 'deleted', NULL),
(15, 'merged', NULL),
(16, 'unlinked', NULL),
(17, 'linked', NULL),
(18, 'login', NULL),
(19, 'logout', NULL),
(20, 'message', NULL),
(21, 'note', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_faq`
--

CREATE TABLE `ostqr_faq` (
  `faq_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL DEFAULT 0,
  `ispublished` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `keywords` tinytext DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`faq_id`),
  UNIQUE KEY `question` (`question`),
  KEY `category_id` (`category_id`),
  KEY `ispublished` (`ispublished`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_faq_category`
--

CREATE TABLE `ostqr_faq_category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_pid` int(10) unsigned DEFAULT NULL,
  `ispublic` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `name` varchar(125) DEFAULT NULL,
  `description` text NOT NULL,
  `notes` tinytext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `ispublic` (`ispublic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_faq_topic`
--

CREATE TABLE `ostqr_faq_topic` (
  `faq_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`faq_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_file`
--

CREATE TABLE `ostqr_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ft` char(1) NOT NULL DEFAULT 'T',
  `bk` char(1) NOT NULL DEFAULT 'D',
  `type` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `key` varchar(86) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `signature` varchar(86) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `attrs` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ft` (`ft`),
  KEY `key` (`key`),
  KEY `signature` (`signature`),
  KEY `type` (`type`),
  KEY `created` (`created`),
  KEY `size` (`size`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_file`
--

INSERT INTO `ostqr_file` VALUES
(1, 'T', 'D', 'image/png', 9452, 'b56944cb4722cc5cda9d1e23a3ea7fbc', 'gjMyblHhAxCQvzLfPBW3EjMUY1AmQQmz', 'powered-by-osticket.png', NULL, '2025-12-10 05:54:55'),
(2, 'T', 'D', 'text/plain', 24, 'dYfzjMWtx86n3ccfeGGNagoRoTDtol7o', 'MWtx86n3ccfeGGNafaacpitTxmJ4h3Ls', 'osTicket.txt', NULL, '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_file_chunk`
--

CREATE TABLE `ostqr_file_chunk` (
  `file_id` int(11) NOT NULL,
  `chunk_id` int(11) NOT NULL,
  `filedata` longblob NOT NULL,
  PRIMARY KEY (`file_id`,`chunk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_file_chunk`
--

INSERT INTO `ostqr_file_chunk` VALUES
(1, 0, '�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0�\0\0\0(\0\0\0�G��\0\0\nCiCCPICC profile\0\0xڝSwX��>��eVB��l�\0"#��Y��\0a�@Ņ�\nV�HUĂ�\nH���(�gA��Z�U\\8�ܧ�}z�����������y��&��j\09R�<:��OH�ɽ�H� ���g�\0\0�yx~t�?��o\0\0p�.$�����P&W\0 �\0�"��R\0�.T�\0�\0�S�d\n\0�\0\0ly|B"\0�\r\0��I>\0ة��\0آ�\0�\0�(G$@�\0`U�R,��\0��@".���Y�2G��\0v�X�@`\0��B,�\0 8\0C� L�0ҿ�_p��H\0�˕͗K�3���\Zw����!��l�Ba)f	�"���#H�L�\0\0\Z����8?������f�l��Ţ�k�o">!�����\0N���_���p��u�k�[\0�V\0h��]3�	�Z\n�z��y8�@��P�<\n�%b��0�>�3�o��~��@��z�\0q�@������qanv�R���B1n��#�ǅ��)��4�\\,��X��P"M�y�R�D!ɕ��2���	�w\r\0��O�N���l�~��X�v\0@~�-�\Z�\0g42y�\0\0����@+\0͗��\0\0��\\��L�\0\0D��*�A�������aD@$�<B�\n��AT�:���\Z�����18\r��\\��p`����	A�a!:�b��"���"aH4��� �Q"��r��Bj�]H#�-r9�\\@���� 2����G1���Q�u@��\Z�Ơs�t4]���k�\Z�=�����K�ut\0}��c��1f��a\\��E`�X\Z&�c�X5V�5cX7v��a�$���^��l���GXLXC�%�#��W	��1�''"��O�%z��xb:��XF�&�!!�%^''_�H$ɒ�N\n!%�2IIkH�H-�S�>�i�L&�m������ �����O�����:ň�L	�$R��J5e?���2B���Qͩ����:�ZIm�vP/S��4u�%͛Cˤ-��Кigi�h/�t�	݃E�З�k�����w\r�\r��Hb(k{��/�L�ӗ��T0�2�g��oUX*�*|���:�V�~��TUsU?�y�T�U�^V}�FU�P�	��թU��6��RwR�P�Q_��_���c\r���F��H�Tc���!�2e�XB�rV�,k�Mb[���Lv�v/{LSCs�f�f�f��q�Ʊ��9ٜJ�!�\r�{--?-��j�f�~�7�zھ�b�r�����up�@�,��:m:�u	�6�Q����u��>�c�y�	������G�m��������7046�l18c�̐c�k�i������h���h��I�''�&�g�5x>f�ob�4�e�k<abi2ۤĤ��)͔k�f�Ѵ�t���,ܬج��9՜k�a�ټ�����E��J�6�ǖږ|��M����V>VyV�V׬I�\\�,�m�WlPW��:�˶�����v�m���)�)�Sn�1���\n���9�a�%�m����;t;|rtu�vlp���4éĩ��Wgg�s��5�K���v�Sm���n�z˕�\Z�ҵ������ܭ�m���=�}��M.��]�=�A���X�q�㝧�����/^v^Y^��O��&��0m���[��{`:>=e���>�>�z�����"�=�#~�~�~���;�������y��N`����\Z��k��5��/>B	\rYr�o���c3�g,����Z�0�&L�����~o��L�̶��Gl��i��})*2�.�Q�Stqt�,֬�Y�g��񏩌�;�j�rvg�jlRlc웸�����x��E�t$	�����=��s�l�3��T�tc��ܢ����˞w<Y5Y�|8����?� BP/O�nM򄛅OE����Q���J<��V��8�;}C�h�OFu�3	OR+y���#�MVD�ެ��q�-9�����R\ri��+�0�(�Of++�\r�y�m������#�s��l�Lѣ�R�PL/�+x[[x�H�HZ�3�f���#�|���P���ظxY��"�E�#�Sw.1]R�dxi��}�h˲��P�XRU�jy��R�ҥ�C+�W4�����n��Z�ca�dU�j��[V*�_�p�����F���WN_�|�ym���J����H��n��Y��J�jA�І�\r���_mJ�t�zj��ʹ���5a5�[̶���6��z�]�V������&�ֿ�w{��;��켵+xWk�E}�n��ݏ\Zb���~ݸGwOŞ�{�{�E��jtolܯ���	mR6�H:p囀oڛ�w�pZ*�A��''ߦ|{�P������ߙ���Hy+�:�u�-�m�=���茣�^G���~�1�cu�5�W���(=��䂓�d���N?=ԙ�y�L��k]Q]�gCϞ?t�L�_�����]�p�"�b�%�K�=�=G~p��H�[o�e���W<�t�M�;����j��s���.]�y�����n&��%���v��w\n�L�]z�x�����������e�m��`�`��Y�	�����Ӈ��G�G�#F#���\r\Z��dΓ᧲���~V�y�s������K�X�����Ͽ�y��r﫩�:�#���y=�����}���ǽ�(�@�P���cǧ�O�>�|��/�����9%\0\0\0tEXtSoftware\0Adobe ImageReadyq�e<\0\0(iTXtXML:com.adobe.xmp\0\0\0\0\0<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?> <x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 5.6-c014 79.156797, 2014/08/20-09:53:02        "> <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"> <rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:stRef="http://ns.adobe.com/xap/1.0/sType/ResourceRef#" xmp:CreatorTool="Adobe Photoshop CC 2014 (Macintosh)" xmpMM:InstanceID="xmp.iid:6E2C95DEA67311E4BDCDDF91FAF94DA5" xmpMM:DocumentID="xmp.did:6E2C95DFA67311E4BDCDDF91FAF94DA5"> <xmpMM:DerivedFrom stRef:instanceID="xmp.iid:CFA74E4FA67111E4BDCDDF91FAF94DA5" stRef:documentID="xmp.did:CFA74E50A67111E4BDCDDF91FAF94DA5"/> </rdf:Description> </rdf:RDF> </x:xmpmeta> <?xpacket end="r"?>����\0\0IDATx��]	�S��?/{2�df�aq�]67�ϭ(*�-\n��.�+�օ� n�J���S�R��:VDT�,e�2�l�����3��L���ݛ�os�N��Pq���$���������s�1�NY96��t����S�/Q��]k~K����z���>�%4ߤ�5���<��,��clmY������''��B�h���B�LZ��M?���\0]s�G�>���Z(4W�]h\r"Ҿ&F4�]���?JKD$�F>Yd-}Q�ZY�e�)���*t��ӄ���$��\r	=(t���Bg	=�����_���єQ\0m�V�+�S�va�D�W�g�����B���B�e���B��L�H���#t�B�	�mFW�\0;t� _���@��њ�x��.t!�[�!#�\\���|��W��:��\rG��I��9��*ʍ6ˁ���Jk�S��A�qG�N��\09���EB�M�~-4?홝�~�I�}�&�y�eY�����o\n�u��{.r��Bk��iv?���LG��є�j�-+��Q散\02%>�|���(^����\n�X��r��T��R��-�*����-��R�˅V���BI�:G�T�#��5i�\ZE"F��lD;�\\_�p��sj�d��B"t��B)�2�w���ϊ��`���Ф�^���MnA!��<�Y�>���������\n�kt�M�Jw%���<.����B�U\\G�BI?禓]\0�o����^����eF�&.���a��a5�͚��#ңo>��=L^���]F����J�N\0�G��ㅾV�\Z��!q#!�����6=X�9�\\T2�ﲨ{��c�捳,Ў)zak�l��@1���{���^��MF��_b��(7�9����+''J��{h�n��[\\�hi��Gc41''''�M��1����>;k�ǐL�����݋���$�|�~�,��ݕ�x� �l��(4W.�\ZAjՈ�r���sr�W���M�W�r�"z�h��>��;��Y�窊E,�0ތ\\�\\1�b����"�''����x���u�LY�ȣx9�)��^[\0�P�XV��NX�ͻ�T("Y���u��W�e�v�݈RU�C55A��C��GY6?���@��1k�VS|�9��I�X���*�rD�"��L���Ύ=*@4�=N�wZj�9�%p���%a��~��yBe����������\r���K�;HT�o�+�)�Q�_Ÿt����cI�U�ȱB"�Vڪ�Vg>L�vW�S�1�|�X���pѰ�y����Zx�rR��''�#��)��W�H�[ ԍ����	�(#�=B2��C�۲@�JL,H$�ݵ(��N)2���''��䘮\Z��/*��''rZ�KD��V�((��g	��ś{��P�]aY� �jߊ=B��\n"4~n�VnwR���X�F�U�rQsΐJd��\Zz��7"�y�7e�cV������������%�B�T`��S�O�;]NNy�X�z7�s��}���~j/�߬\rn����F�z���*��f�ۉ洌5)��E��EK|��j�4��4\rI.��x����.�j�6��GJ�G_��Ә�Zz1`Nx�P��<8�^��$6�v�hUY�\n�G���jrެ/^�D����a�S��ۚIm·L��\Z�^ f��Z��A36�ck��{,\Z9�Rܱ@W�Q%��Z�d���Wm��o��''rK��J���U0�7YާD~&*�������1~��&=PH:	��e�ְȁ~��|�d4ş:�҇��\n��{��ţTǹ+h�,��9ww��z��X\0�����-�K��N/R������\r�3-H��h+�apymv+��gɧ�7��E#�:��*����Z;x��΁w�*��Kq�8W�Q���ȶ<�{X�&�ң�xPTR�;Pđ �#�����%·''��H/�d���&A�y��?�����Ljȇ6�="�9�t9\Z_��2I$��\0�K�,�-"�h���g.��v��8߼�a�=�ٞ]MV*D-z�c0:�z7y�ɣGϯ(/y=�|ҧ^[�Ӻ�ca�q�>ѺQj���)�bD���ky��J@���c��K�����leh\rK���)��Axn�v�F8\r�J��Bww*%Gl^͖̋*�D�LV���� �)Q�x��1�NT�7o��.�|�e�S�V�>^�����B/�\Z�ҽ��qSE���>;-��41�t����iD�瓍8U�}''�"�OB�z��#����w���v8;���I�F>�:Թ�㰀�O4D��r�����S�m�.��F!%�8䊛I��y"�������e�*H�NE�f�t5��K#��L��B���E�3��6P����$�V72��;��P"1�Óȹ������ڹ��\\y�� �(�r�"�W�>�����z�S�}��|?A��6N���y΋p9H��\0����6�1�6ʧP�Z}i�"���R7�%��O��č��ыkCU!j/@61�z	�''�[�~��wף�7V\0q_�+�}�o^e4"6����¨�s����!��\\r��k�JN�T�$@�Q�N���S�������$yZ(_�:�{���W,��\r�/��u�\Zs�x��Ѱqh�����.��}	����g(�b[\Z�s�L7��RF��+�%�(��G�8"�4�r��)�5V��6I��F�\r:� XR>9��Q;G)ڴ����^��LȰR�#���.c�/ ��5/d�Izf9�,��}Og+>{8���xq�*���k��^�Z`5��r�u��u��ʠ��"�I��E[uT�\\�\n�q���f�-�ϵ�ͺ/I4%8�{0�7"W+k���T��Ga_�dC:���2����v\0�Y���-���{���0ǟN�6V�����!1��y��\0@�LF�y�@:�:x�:�/+E�îu.^f=0	�W�V"b��K�5�3G��ht�#�+��>?��ǽ=���0�}0��t�ɼ��u\r�V���9�)�ftѼ~;��W�9Xt�tƊ#)\n6Ex�9r���8���_K���g����D�������+	ȸ�\n���Z���u��-@�G��L���M\Z��`��^N�\r�^F�ȫ	�����` #��bL�FD�~�x֎@7���:���!l�1�l\Z��''�9@p)�b�PbN�UP��q�����t��8��"�''�\r\\&!ª���&OGGׂb�nf`]�0��N=m?��k����X�F$?��2�bP\n��ؕp�0��{�EAoh��|��d�Y�E,�qjQe�0��T`��K|4bf.�D�f�����o��N�D�Á���=l,uف1�\\����v�U����P��w�B�G_�)1�\0�N�o������C�����&ҁ��痁�<Pq~�6����cmZ����b>�	�\\�U�����'' �y�>!ܶF��G�,�G���MO�f �uQ������nx�����H�rL<�4�?f/��qR���Jʿ�ɤ%e"���2�s!֧�!��''�~��p\r#Je�+R=u���m�^J��U�|���F�op�C���(h_oI3��]puB4�+�q.��C���I[�IM�gTm(��F�F�g/"�X���A��]��\03#��)I�5�r���cӨ}ʪ�G���@�@Q�|\0��E(�N���w��̥�uD�K\0��h�*�Y�C�.�1��UrX4<�y��̐;���_B�@�D1p~mx�V�ޯ�g�5Ze�+x���H��''�P\rD龬��lw����P��d�x�>]h���B����G���G���R�|��`���Q��v���Ӡ�B��C,ERO�g*��/6��9�p�8!ĭ��씯�q"BZ45xH2Ţ-G:��I83%���$�|��aY�\0<ܴ�Z��W���0�&����aTn��U��â�Zt���ep�\Z��i#E���F�6���*��\\��o��&H''	�=�c6�m"Ķ6�W���JVQSq*겨b���,�Q����d��{�4��{r���u!Ʋ��F�n��-赒��7a��L�����7i@�{P�L閮%$��(��''q��c���w`��`@��5	�e�����\Z����9�fգ���V%������M(�ë�q�a���s���Q��w^��w�\nRZ0ǲ�E�O�tn`Ň�藸eY=�m.���''2_��CN`Ʈ�(!�k��M�č�4u���%�4)��H�[��/�;��}\\��8�*�X���=Mwh\r\Zt\n�\\''"�\nƄ�Z~M3��-9�8�R8��g�_@uWN��4��ꓚϹ�5b5��T^RcSVh�b�>b\0#��5:�,�w�cT��Pma������''� �E	e0�XԎBI�Fx\\y���U��"�8�r���[��E�r:!5�dIA��h�''Z4Wt�����g�4醲�v�<�Q�]�-��\\��A(5`m,�	皌�V�\Z�Xd��*��Pb��<�B%+�#c.V*���P���,Vՙy(:�\0�F#"|Fu7����l+\0(����ŀ�b�����`xڗPR�7՝*)�.^U(�\\�Μ��;��脫PЙ\0�y�\Z�������\0�j��8���\Z�����y�d�Q�e���Z�	�EO����h�u)���h�3�!�[SU�''��_��q����(.��RO�B�b�W�Ѷh�ԋG\r�N���)����|V�F�h��&D]���E4 k�y6hw���=���?D��''����u�b-�Ts��G���y�y��`8����<�\na+V�\rh�2	�x��1�іMA��y�)l�k$����H��y�7��t\r��j�H�/6-�J�u&<}"�Qĕn@{�j�K\Z�.`-N�Bچ�ӫh�M/^���\\߀1vS�/GJP�!�6#���9�:Cb������DčR�_�9���C\r��SU]SE4;���B�o�"�(���Px)''��̵pʲ�	ޝӜ{�P�4	��0,@:�L���\\j�_��g�08�0�c�"!��,x77��\Z\n��d�"~�h������~P�9I��,FS��;km@F2?\n%�5z|:��5h�D��C�tG�TET��}-��qz�{\n��iI�Q�3�#��dt�-�!�DWD�#w#e&��\Z��QND�w���ݔj�q���{p��k���+܏{gZǫrХl��"�l�m$l�p$I?�1�`<���:$���Bi�b�B��c]��݀k8q��v�C�d�W��xU�''�y�������Q��.�=o��3��V�� %��|F��=�V�+��$�E''^9O�7K��L��轲Z��ȫ�I�4x��a���A��>��g�Џ����\0`_c:\Z��\rF�(D�~@3ѷ3)��S:�� _?𵀓\\�M)��8�~x/����F!�Pn�p/ؽ��%h[p݋Xes,ھđ�\nie�L���D��JKKr��u�A�)J�w"�d����x^���W��\np���$��\0D�(�-�]�]��:�hk���i��d3�����+��;��Un�4\nKɶP(P�h���\n;^�Ʋ�,]|��X�˫�Tw	V���v\0�u���ྞbS(��ٖZ?=g`x��ѡ5�MY9\Z��\\S�l3�e:Y	j�Bn�v�J5�s�z��S��.''��%�jh̜�\0Z=_�\Z���h`oe[���)�#�2�i����M�7י�bV����N@t�S�_]����wfHu͙He��m����Hk Z�D۽��''(�����NT��|_;�"��VJL�ɔi����/�Bh�����8�"��/�!w�������F5��vT!+Q��/A�FOҘ��4�C�\Zp0jC�\nJ�''6��Q�~�7vD3/�B5���@�Z p����_�\0�௘s]J�\0\0\0\0IEND�B`�'),
(2, 0, 'Canned Attachments Rock!');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_filter`
--

CREATE TABLE `ostqr_filter` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `execorder` int(10) unsigned NOT NULL DEFAULT 99,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `flags` int(10) unsigned DEFAULT 0,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `match_all_rules` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `stop_onmatch` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `target` enum('Any','Web','Email','API') NOT NULL DEFAULT 'Any',
  `email_id` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(32) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `target` (`target`),
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_filter`
--

INSERT INTO `ostqr_filter` VALUES
(1, 99, 1, 0, 0, 0, 0, 'Email', 0, 'SYSTEM BAN LIST', 'Internal list for email banning. Do not remove', '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_filter_action`
--

CREATE TABLE `ostqr_filter_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT 0,
  `type` varchar(24) NOT NULL,
  `configuration` text DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `filter_id` (`filter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_filter_action`
--

INSERT INTO `ostqr_filter_action` VALUES
(1, 1, 1, 'reject', '[]', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_filter_rule`
--

CREATE TABLE `ostqr_filter_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` int(10) unsigned NOT NULL DEFAULT 0,
  `what` varchar(32) NOT NULL,
  `how` enum('equal','not_equal','contains','dn_contain','starts','ends','match','not_match') NOT NULL,
  `val` varchar(255) NOT NULL,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `notes` tinytext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filter` (`filter_id`,`what`,`how`,`val`),
  KEY `filter_id` (`filter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_filter_rule`
--

INSERT INTO `ostqr_filter_rule` VALUES
(1, 1, 'email', 'equal', 'test@example.com', 1, '', '0000-00-00 00:00:00', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_form`
--

CREATE TABLE `ostqr_form` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned DEFAULT NULL,
  `type` varchar(8) NOT NULL DEFAULT 'G',
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `instructions` varchar(512) DEFAULT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_form`
--

INSERT INTO `ostqr_form` VALUES
(1, NULL, 'U', 1, 'Contact Information', NULL, '', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, NULL, 'T', 1, 'Ticket Details', 'Please Describe Your Issue', '', 'This form will be attached to every ticket, regardless of its source.\nYou can add any fields to this form and they will be available to all\ntickets, and will be searchable with advanced search and filterable.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(3, NULL, 'C', 1, 'Company Information', 'Details available in email templates', '', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(4, NULL, 'O', 1, 'Organization Information', 'Details on user organization', '', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(5, NULL, 'A', 1, 'Task Details', 'Please Describe The Issue', '', 'This form is used to create a task.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(6, NULL, 'L1', 0, 'Ticket Status Properties', 'Properties that can be set on a ticket status.', '', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_form_entry`
--

CREATE TABLE `ostqr_form_entry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(11) unsigned NOT NULL,
  `object_id` int(11) unsigned DEFAULT NULL,
  `object_type` char(1) NOT NULL DEFAULT 'T',
  `sort` int(11) unsigned NOT NULL DEFAULT 1,
  `extra` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_lookup` (`object_type`,`object_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_form_entry`
--

INSERT INTO `ostqr_form_entry` VALUES
(1, 4, 1, 'O', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 3, NULL, 'C', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(9, 1, 3, 'U', 1, NULL, '2025-12-10 09:40:03', '2025-12-10 09:40:03'),
(10, 2, 5, 'T', 0, '{"disable":[]}', '2025-12-10 09:40:03', '2025-12-10 09:40:03');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_form_entry_values`
--

CREATE TABLE `ostqr_form_entry_values` (
  `entry_id` int(11) unsigned NOT NULL,
  `field_id` int(11) unsigned NOT NULL,
  `value` text DEFAULT NULL,
  `value_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`entry_id`,`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_form_entry_values`
--

INSERT INTO `ostqr_form_entry_values` VALUES
(1, 28, NULL, NULL),
(1, 29, NULL, NULL),
(1, 30, NULL, NULL),
(1, 31, NULL, NULL),
(2, 23, 'APEXS Support Ticket System', NULL),
(2, 24, 'https://support.apexsinc.com', NULL),
(2, 25, '09173129336', NULL),
(2, 26, 'Building 1, Suite 714, EGI City By The Sea, Maribago, Lapu-Lapu City, Cebu 6015, PH', NULL),
(9, 3, NULL, NULL),
(9, 4, NULL, NULL),
(10, 20, 'asdfasdfasdf', NULL),
(10, 22, 'Normal', 2);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_form_field`
--

CREATE TABLE `ostqr_form_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(11) unsigned NOT NULL,
  `flags` int(10) unsigned DEFAULT 1,
  `type` varchar(255) NOT NULL DEFAULT 'text',
  `label` varchar(255) NOT NULL,
  `name` varchar(64) NOT NULL,
  `configuration` text DEFAULT NULL,
  `sort` int(11) unsigned NOT NULL,
  `hint` varchar(512) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `sort` (`sort`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_form_field`
--

INSERT INTO `ostqr_form_field` VALUES
(1, 1, 489395, 'text', 'Email Address', 'email', '{"size":40,"length":64,"validator":"email"}', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 1, 489395, 'text', 'Full Name', 'name', '{"size":40,"length":64}', 2, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(3, 1, 13057, 'phone', 'Phone Number', 'phone', NULL, 3, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(4, 1, 12289, 'memo', 'Internal Notes', 'notes', '{"rows":4,"cols":40}', 4, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(20, 2, 489265, 'text', 'Issue Summary', 'subject', '{"size":40,"length":50}', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(21, 2, 480547, 'thread', 'Issue Details', 'message', '{"attachments":false,"size":524288,"mimetypes":null,"extensions":"","strictmimecheck":false,"max":""}', 2, '<p>Details on the reason(s) for opening the ticket.</p>', '2025-12-10 05:54:55', '2025-12-10 09:44:04'),
(22, 2, 274609, 'priority', 'Priority Level', 'priority', NULL, 3, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(23, 3, 291249, 'text', 'Company Name', 'name', '{"size":40,"length":64}', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(24, 3, 274705, 'text', 'Website', 'website', '{"size":40,"length":64}', 2, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(25, 3, 274705, 'phone', 'Phone Number', 'phone', '{"ext":false}', 3, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(26, 3, 12545, 'memo', 'Address', 'address', '{"rows":2,"cols":40,"html":false,"length":100}', 4, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(27, 4, 489395, 'text', 'Name', 'name', '{"size":40,"length":64}', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(28, 4, 13057, 'memo', 'Address', 'address', '{"rows":2,"cols":40,"length":100,"html":false}', 2, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(29, 4, 13057, 'phone', 'Phone', 'phone', NULL, 3, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(30, 4, 13057, 'text', 'Website', 'website', '{"size":40,"length":0}', 4, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(31, 4, 12289, 'memo', 'Internal Notes', 'notes', '{"rows":4,"cols":40}', 5, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(32, 5, 487601, 'text', 'Title', 'title', '{"size":40,"length":50}', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(33, 5, 413939, 'thread', 'Description', 'description', NULL, 2, 'Details on the reason(s) for creating the task.', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(34, 6, 487665, 'state', 'State', 'state', '{"prompt":"State of a ticket"}', 1, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(35, 6, 471073, 'memo', 'Description', 'description', '{"rows":"2","cols":"40","html":"","length":"100"}', 3, NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_group`
--

CREATE TABLE `ostqr_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) unsigned NOT NULL,
  `flags` int(11) unsigned NOT NULL DEFAULT 1,
  `name` varchar(120) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_help_topic`
--

CREATE TABLE `ostqr_help_topic` (
  `topic_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `ispublic` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `noautoresp` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned DEFAULT 0,
  `status_id` int(10) unsigned NOT NULL DEFAULT 0,
  `priority_id` int(10) unsigned NOT NULL DEFAULT 0,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sla_id` int(10) unsigned NOT NULL DEFAULT 0,
  `page_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sequence_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 0,
  `topic` varchar(128) NOT NULL DEFAULT '',
  `number_format` varchar(32) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`topic_id`),
  UNIQUE KEY `topic` (`topic`,`topic_pid`),
  KEY `topic_pid` (`topic_pid`),
  KEY `priority_id` (`priority_id`),
  KEY `dept_id` (`dept_id`),
  KEY `staff_id` (`staff_id`,`team_id`),
  KEY `sla_id` (`sla_id`),
  KEY `page_id` (`page_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_help_topic`
--

INSERT INTO `ostqr_help_topic` VALUES
(1, 0, 1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 2, 'General Inquiry', NULL, 'Questions about products or services', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 'Feedback', NULL, '<p>Tickets that primarily concern the sales and billing departments</p>', '2025-12-10 05:54:55', '2025-12-10 06:58:28'),
(10, 0, 1, 0, 2, 0, 2, 3, 0, 0, 0, 0, 0, 3, 'Report a Problem', NULL, 'Product, service, or equipment related issues', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(11, 10, 1, 0, 2, 0, 3, 0, 0, 0, 1, 0, 0, 4, 'Access Issue', NULL, 'Report an inability access a physical or virtual asset', '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_help_topic_form`
--

CREATE TABLE `ostqr_help_topic_form` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) unsigned NOT NULL DEFAULT 0,
  `form_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 1,
  `extra` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `topic-form` (`topic_id`,`form_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_help_topic_form`
--

INSERT INTO `ostqr_help_topic_form` VALUES
(1, 1, 2, 1, '{"disable":[]}'),
(2, 2, 2, 1, '{"disable":[]}'),
(3, 10, 2, 1, '{"disable":[]}'),
(4, 11, 2, 1, '{"disable":[]}');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_list`
--

CREATE TABLE `ostqr_list` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_plural` varchar(255) DEFAULT NULL,
  `sort_mode` enum('Alpha','-Alpha','SortCol') NOT NULL DEFAULT 'Alpha',
  `masks` int(11) unsigned NOT NULL DEFAULT 0,
  `type` varchar(16) DEFAULT NULL,
  `configuration` text NOT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_list`
--

INSERT INTO `ostqr_list` VALUES
(1, 'Ticket Status', 'Ticket Statuses', 'SortCol', 13, 'ticket-status', '{"handler":"TicketStatusList"}', 'Ticket statuses', '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_list_items`
--

CREATE TABLE `ostqr_list_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(11) DEFAULT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 1,
  `value` varchar(255) NOT NULL,
  `extra` varchar(255) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `properties` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `list_item_lookup` (`list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_lock`
--

CREATE TABLE `ostqr_lock` (
  `lock_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `expire` datetime DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`lock_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_note`
--

CREATE TABLE `ostqr_note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT NULL,
  `staff_id` int(11) unsigned NOT NULL DEFAULT 0,
  `ext_id` varchar(10) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ext_id` (`ext_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_organization`
--

CREATE TABLE `ostqr_organization` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `manager` varchar(16) NOT NULL DEFAULT '',
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `domain` varchar(256) NOT NULL DEFAULT '',
  `extra` text DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_organization`
--

INSERT INTO `ostqr_organization` VALUES
(1, 'APEXS', '', 8, '', NULL, '2025-12-10 05:54:55', '2025-12-10 07:08:18');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_organization__cdata`
--

CREATE TABLE `ostqr_organization__cdata` (
  `org_id` int(11) unsigned NOT NULL DEFAULT 0,
  `name` mediumtext DEFAULT NULL,
  `address` mediumtext DEFAULT NULL,
  `phone` mediumtext DEFAULT NULL,
  `website` mediumtext DEFAULT NULL,
  `notes` mediumtext DEFAULT NULL,
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_organization__cdata`
--

INSERT INTO `ostqr_organization__cdata` VALUES
(1, NULL, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_plugin`
--

CREATE TABLE `ostqr_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `install_path` varchar(60) NOT NULL,
  `isphar` tinyint(1) NOT NULL DEFAULT 0,
  `isactive` tinyint(1) NOT NULL DEFAULT 0,
  `version` varchar(64) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `installed` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `install_path` (`install_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_plugin_instance`
--

CREATE TABLE `ostqr_plugin_instance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `plugin_id` int(11) unsigned NOT NULL,
  `flags` int(10) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plugin_id` (`plugin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_queue`
--

CREATE TABLE `ostqr_queue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT 0,
  `columns_id` int(11) unsigned DEFAULT NULL,
  `sort_id` int(11) unsigned DEFAULT NULL,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `title` varchar(60) DEFAULT NULL,
  `config` text DEFAULT NULL,
  `filter` varchar(64) DEFAULT NULL,
  `root` varchar(32) DEFAULT NULL,
  `path` varchar(80) NOT NULL DEFAULT '/',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_queue`
--

INSERT INTO `ostqr_queue` VALUES
(1, 0, NULL, 1, 3, 0, 1, 'Open', '[["status__state","includes",{"open":"Open"}]]', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(2, 1, NULL, 4, 43, 0, 1, 'Open', '{"criteria":[["isanswered","nset",null]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(3, 1, NULL, 4, 43, 0, 2, 'Answered', '{"criteria":[["isanswered","set",null]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(4, 1, NULL, 4, 43, 0, 3, 'Overdue', '{"criteria":[["isoverdue","set",null]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(5, 0, NULL, 3, 3, 0, 3, 'My Tickets', '{"criteria":[["assignee","includes",{"M":"Me","T":"One of my teams"}],["status__state","includes",{"open":"Open"}]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(6, 5, NULL, NULL, 43, 0, 1, 'Assigned to Me', '{"criteria":[["assignee","includes",{"M":"Me"}]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(7, 5, NULL, NULL, 43, 0, 2, 'Assigned to Teams', '{"criteria":[["assignee","!includes",{"M":"Me"}]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(8, 0, NULL, 5, 3, 0, 4, 'Closed', '{"criteria":[["status__state","includes",{"closed":"Closed"}]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(9, 8, NULL, 5, 43, 0, 1, 'Today', '{"criteria":[["closed","period","td"]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(10, 8, NULL, 5, 43, 0, 2, 'Yesterday', '{"criteria":[["closed","period","yd"]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(11, 8, NULL, 5, 43, 0, 3, 'This Week', '{"criteria":[["closed","period","tw"]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(12, 8, NULL, 5, 43, 0, 4, 'This Month', '{"criteria":[["closed","period","tm"]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(13, 8, NULL, 6, 43, 0, 5, 'This Quarter', '{"criteria":[["closed","period","tq"]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(14, 8, NULL, 7, 43, 0, 6, 'This Year', '{"criteria":[["closed","period","ty"]],"conditions":[]}', NULL, 'T', '/', '2025-12-10 05:54:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_queue_column`
--

CREATE TABLE `ostqr_queue_column` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) NOT NULL DEFAULT '',
  `primary` varchar(64) NOT NULL DEFAULT '',
  `secondary` varchar(64) DEFAULT NULL,
  `filter` varchar(32) DEFAULT NULL,
  `truncate` varchar(16) DEFAULT NULL,
  `annotations` text DEFAULT NULL,
  `conditions` text DEFAULT NULL,
  `extra` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_queue_column`
--

INSERT INTO `ostqr_queue_column` VALUES
(1, 0, 'Ticket #', 'number', NULL, 'link:ticketP', 'wrap', '[{"c":"TicketSourceDecoration","p":"b"}]', '[{"crit":["isanswered","nset",null],"prop":{"font-weight":"bold"}}]', NULL),
(2, 0, 'Date Created', 'created', NULL, 'date:full', 'wrap', '[]', '[]', NULL),
(3, 0, 'Subject', 'cdata__subject', NULL, 'link:ticket', 'ellipsis', '[{"c":"TicketThreadCount","p":">"},{"c":"ThreadAttachmentCount","p":"a"},{"c":"OverdueFlagDecoration","p":"<"},{"c":"LockDecoration","p":"<"}]', '[{"crit":["isanswered","nset",null],"prop":{"font-weight":"bold"}}]', NULL),
(4, 0, 'User Name', 'user__name', NULL, NULL, 'wrap', '[{"c":"ThreadCollaboratorCount","p":">"}]', '[]', NULL),
(5, 0, 'Priority', 'cdata__priority', NULL, NULL, 'wrap', '[]', '[]', NULL),
(6, 0, 'Status', 'status__id', NULL, NULL, 'wrap', '[]', '[]', NULL),
(7, 0, 'Close Date', 'closed', NULL, 'date:full', 'wrap', '[]', '[]', NULL),
(8, 0, 'Assignee', 'assignee', NULL, NULL, 'wrap', '[]', '[]', NULL),
(9, 0, 'Due Date', 'duedate', 'est_duedate', 'date:human', 'wrap', '[]', '[]', NULL),
(10, 0, 'Last Updated', 'lastupdate', NULL, 'date:full', 'wrap', '[]', '[]', NULL),
(11, 0, 'Department', 'dept_id', NULL, NULL, 'wrap', '[]', '[]', NULL),
(12, 0, 'Last Message', 'thread__lastmessage', NULL, 'date:human', 'wrap', '[]', '[]', NULL),
(13, 0, 'Last Response', 'thread__lastresponse', NULL, 'date:human', 'wrap', '[]', '[]', NULL),
(14, 0, 'Team', 'team_id', NULL, NULL, 'wrap', '[]', '[]', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_queue_columns`
--

CREATE TABLE `ostqr_queue_columns` (
  `queue_id` int(11) unsigned NOT NULL,
  `column_id` int(11) unsigned NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `bits` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 1,
  `heading` varchar(64) DEFAULT NULL,
  `width` int(10) unsigned NOT NULL DEFAULT 100,
  PRIMARY KEY (`queue_id`,`column_id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_queue_columns`
--

INSERT INTO `ostqr_queue_columns` VALUES
(1, 1, 0, 1, 1, 'Ticket', 100),
(1, 3, 0, 1, 3, 'Subject', 300),
(1, 4, 0, 1, 4, 'From', 185),
(1, 5, 0, 1, 5, 'Priority', 85),
(1, 8, 0, 1, 6, 'Assigned To', 160),
(1, 10, 0, 1, 2, 'Last Updated', 150),
(2, 1, 0, 1, 1, 'Ticket', 100),
(2, 3, 0, 1, 3, 'Subject', 300),
(2, 4, 0, 1, 4, 'From', 185),
(2, 5, 0, 1, 5, 'Priority', 85),
(2, 8, 0, 1, 6, 'Assigned To', 160),
(2, 10, 0, 1, 2, 'Last Updated', 150),
(3, 1, 0, 1, 1, 'Ticket', 100),
(3, 3, 0, 1, 3, 'Subject', 300),
(3, 4, 0, 1, 4, 'From', 185),
(3, 5, 0, 1, 5, 'Priority', 85),
(3, 8, 0, 1, 6, 'Assigned To', 160),
(3, 10, 0, 1, 2, 'Last Updated', 150),
(4, 1, 0, 1, 1, 'Ticket', 100),
(4, 3, 0, 1, 3, 'Subject', 300),
(4, 4, 0, 1, 4, 'From', 185),
(4, 5, 0, 1, 5, 'Priority', 85),
(4, 8, 0, 1, 6, 'Assigned To', 160),
(4, 9, 0, 1, 9, 'Due Date', 150),
(5, 1, 0, 1, 1, 'Ticket', 100),
(5, 3, 0, 1, 3, 'Subject', 300),
(5, 4, 0, 1, 4, 'From', 185),
(5, 5, 0, 1, 5, 'Priority', 85),
(5, 10, 0, 1, 2, 'Last Update', 150),
(5, 11, 0, 1, 6, 'Department', 160),
(6, 1, 0, 1, 1, 'Ticket', 100),
(6, 3, 0, 1, 3, 'Subject', 300),
(6, 4, 0, 1, 4, 'From', 185),
(6, 5, 0, 1, 5, 'Priority', 85),
(6, 10, 0, 1, 2, 'Last Update', 150),
(6, 11, 0, 1, 6, 'Department', 160),
(7, 1, 0, 1, 1, 'Ticket', 100),
(7, 3, 0, 1, 3, 'Subject', 300),
(7, 4, 0, 1, 4, 'From', 185),
(7, 5, 0, 1, 5, 'Priority', 85),
(7, 10, 0, 1, 2, 'Last Update', 150),
(7, 14, 0, 1, 6, 'Team', 160),
(8, 1, 0, 1, 1, 'Ticket', 100),
(8, 3, 0, 1, 3, 'Subject', 300),
(8, 4, 0, 1, 4, 'From', 185),
(8, 7, 0, 1, 2, 'Date Closed', 150),
(8, 8, 0, 1, 6, 'Closed By', 160),
(9, 1, 0, 1, 1, 'Ticket', 100),
(9, 3, 0, 1, 3, 'Subject', 300),
(9, 4, 0, 1, 4, 'From', 185),
(9, 7, 0, 1, 2, 'Date Closed', 150),
(9, 8, 0, 1, 6, 'Closed By', 160),
(10, 1, 0, 1, 1, 'Ticket', 100),
(10, 3, 0, 1, 3, 'Subject', 300),
(10, 4, 0, 1, 4, 'From', 185),
(10, 7, 0, 1, 2, 'Date Closed', 150),
(10, 8, 0, 1, 6, 'Closed By', 160),
(11, 1, 0, 1, 1, 'Ticket', 100),
(11, 3, 0, 1, 3, 'Subject', 300),
(11, 4, 0, 1, 4, 'From', 185),
(11, 7, 0, 1, 2, 'Date Closed', 150),
(11, 8, 0, 1, 6, 'Closed By', 160),
(12, 1, 0, 1, 1, 'Ticket', 100),
(12, 3, 0, 1, 3, 'Subject', 300),
(12, 4, 0, 1, 4, 'From', 185),
(12, 7, 0, 1, 2, 'Date Closed', 150),
(12, 8, 0, 1, 6, 'Closed By', 160),
(13, 1, 0, 1, 1, 'Ticket', 100),
(13, 3, 0, 1, 3, 'Subject', 300),
(13, 4, 0, 1, 4, 'From', 185),
(13, 7, 0, 1, 2, 'Date Closed', 150),
(13, 8, 0, 1, 6, 'Closed By', 160),
(14, 1, 0, 1, 1, 'Ticket', 100),
(14, 3, 0, 1, 3, 'Subject', 300),
(14, 4, 0, 1, 4, 'From', 185),
(14, 7, 0, 1, 2, 'Date Closed', 150),
(14, 8, 0, 1, 6, 'Closed By', 160);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_queue_config`
--

CREATE TABLE `ostqr_queue_config` (
  `queue_id` int(11) unsigned NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `setting` text DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`queue_id`,`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_queue_export`
--

CREATE TABLE `ostqr_queue_export` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `queue_id` int(11) unsigned NOT NULL,
  `path` varchar(64) NOT NULL DEFAULT '',
  `heading` varchar(64) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `queue_id` (`queue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_queue_sort`
--

CREATE TABLE `ostqr_queue_sort` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `root` varchar(32) DEFAULT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `columns` text DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_queue_sort`
--

INSERT INTO `ostqr_queue_sort` VALUES
(1, NULL, 'Priority + Most Recently Updated', '["-cdata__priority","-lastupdate"]', '2025-12-10 05:54:55'),
(2, NULL, 'Priority + Most Recently Created', '["-cdata__priority","-created"]', '2025-12-10 05:54:55'),
(3, NULL, 'Priority + Due Date', '["-cdata__priority","-est_duedate"]', '2025-12-10 05:54:55'),
(4, NULL, 'Due Date', '["-est_duedate"]', '2025-12-10 05:54:55'),
(5, NULL, 'Closed Date', '["-closed"]', '2025-12-10 05:54:55'),
(6, NULL, 'Create Date', '["-created"]', '2025-12-10 05:54:55'),
(7, NULL, 'Update Date', '["-lastupdate"]', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_queue_sorts`
--

CREATE TABLE `ostqr_queue_sorts` (
  `queue_id` int(11) unsigned NOT NULL,
  `sort_id` int(11) unsigned NOT NULL,
  `bits` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`queue_id`,`sort_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_queue_sorts`
--

INSERT INTO `ostqr_queue_sorts` VALUES
(1, 1, 0, 0),
(1, 2, 0, 0),
(1, 3, 0, 0),
(1, 4, 0, 0),
(1, 6, 0, 0),
(1, 7, 0, 0),
(5, 1, 0, 0),
(5, 2, 0, 0),
(5, 3, 0, 0),
(5, 4, 0, 0),
(5, 6, 0, 0),
(5, 7, 0, 0),
(6, 1, 0, 0),
(6, 2, 0, 0),
(6, 3, 0, 0),
(6, 4, 0, 0),
(6, 6, 0, 0),
(6, 7, 0, 0),
(7, 1, 0, 0),
(7, 2, 0, 0),
(7, 3, 0, 0),
(7, 4, 0, 0),
(7, 6, 0, 0),
(7, 7, 0, 0),
(8, 1, 0, 0),
(8, 2, 0, 0),
(8, 3, 0, 0),
(8, 4, 0, 0),
(8, 5, 0, 0),
(8, 6, 0, 0),
(8, 7, 0, 0),
(9, 1, 0, 0),
(9, 2, 0, 0),
(9, 3, 0, 0),
(9, 4, 0, 0),
(9, 5, 0, 0),
(9, 6, 0, 0),
(9, 7, 0, 0),
(10, 1, 0, 0),
(10, 2, 0, 0),
(10, 3, 0, 0),
(10, 4, 0, 0),
(10, 5, 0, 0),
(10, 6, 0, 0),
(10, 7, 0, 0),
(11, 1, 0, 0),
(11, 2, 0, 0),
(11, 3, 0, 0),
(11, 4, 0, 0),
(11, 5, 0, 0),
(11, 6, 0, 0),
(11, 7, 0, 0),
(12, 1, 0, 0),
(12, 2, 0, 0),
(12, 3, 0, 0),
(12, 4, 0, 0),
(12, 5, 0, 0),
(12, 6, 0, 0),
(12, 7, 0, 0),
(13, 1, 0, 0),
(13, 2, 0, 0),
(13, 3, 0, 0),
(13, 4, 0, 0),
(13, 5, 0, 0),
(13, 6, 0, 0),
(13, 7, 0, 0),
(14, 1, 0, 0),
(14, 2, 0, 0),
(14, 3, 0, 0),
(14, 4, 0, 0),
(14, 5, 0, 0),
(14, 6, 0, 0),
(14, 7, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_role`
--

CREATE TABLE `ostqr_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `name` varchar(64) DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_role`
--

INSERT INTO `ostqr_role` VALUES
(1, 1, 'All Access', '{"ticket.assign":1,"ticket.close":1,"ticket.create":1,"ticket.delete":1,"ticket.edit":1,"thread.edit":1,"ticket.link":1,"ticket.markanswered":1,"ticket.merge":1,"ticket.reply":1,"ticket.refer":1,"ticket.release":1,"ticket.transfer":1,"task.assign":1,"task.close":1,"task.create":1,"task.delete":1,"task.edit":1,"task.reply":1,"task.transfer":1,"canned.manage":1}', 'Role with unlimited access', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 1, 'Expanded Access', '{"ticket.assign":1,"ticket.close":1,"ticket.create":1,"ticket.edit":1,"ticket.link":1,"ticket.merge":1,"ticket.reply":1,"ticket.refer":1,"ticket.release":1,"ticket.transfer":1,"task.assign":1,"task.close":1,"task.create":1,"task.edit":1,"task.reply":1,"task.transfer":1,"canned.manage":1}', 'Role with expanded access', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(3, 1, 'Limited Access', '{"ticket.assign":1,"ticket.create":1,"ticket.link":1,"ticket.merge":1,"ticket.refer":1,"ticket.release":1,"ticket.transfer":1,"task.assign":1,"task.reply":1,"task.transfer":1}', 'Role with limited access', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(4, 1, 'View only', NULL, 'Simple role with no permissions', '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_schedule`
--

CREATE TABLE `ostqr_schedule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `timezone` varchar(64) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_schedule`
--

INSERT INTO `ostqr_schedule` VALUES
(1, 1, 'Monday - Friday 8am - 5pm with U.S. Holidays', NULL, '', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 1, '24/7', NULL, '', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(3, 1, '24/5', NULL, '', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(4, 0, 'U.S. Holidays', NULL, '', '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_schedule_entry`
--

CREATE TABLE `ostqr_schedule_entry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `repeats` varchar(16) NOT NULL DEFAULT 'never',
  `starts_on` date DEFAULT NULL,
  `starts_at` time DEFAULT NULL,
  `ends_on` date DEFAULT NULL,
  `ends_at` time DEFAULT NULL,
  `stops_on` datetime DEFAULT NULL,
  `day` tinyint(4) DEFAULT NULL,
  `week` tinyint(4) DEFAULT NULL,
  `month` tinyint(4) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `repeats` (`repeats`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_schedule_entry`
--

INSERT INTO `ostqr_schedule_entry` VALUES
(1, 1, 0, 0, 'Monday', 'weekly', '2019-01-07', '08:00:00', '2019-01-07', '17:00:00', NULL, 1, NULL, NULL, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(2, 1, 0, 0, 'Tuesday', 'weekly', '2019-01-08', '08:00:00', '2019-01-08', '17:00:00', NULL, 2, NULL, NULL, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(3, 1, 0, 0, 'Wednesday', 'weekly', '2019-01-09', '08:00:00', '2019-01-09', '17:00:00', NULL, 3, NULL, NULL, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(4, 1, 0, 0, 'Thursday', 'weekly', '2019-01-10', '08:00:00', '2019-01-10', '17:00:00', NULL, 4, NULL, NULL, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(5, 1, 0, 0, 'Friday', 'weekly', '2019-01-11', '08:00:00', '2019-01-11', '17:00:00', NULL, 5, NULL, NULL, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(6, 2, 0, 0, 'Daily', 'daily', '2019-01-01', '00:00:00', '2019-01-01', '23:59:59', NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(7, 3, 0, 0, 'Weekdays', 'weekdays', '2019-01-01', '00:00:00', '2019-01-01', '23:59:59', NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(8, 4, 0, 0, 'New Year''s Day', 'yearly', '2019-01-01', '00:00:00', '2019-01-01', '23:59:59', NULL, 1, NULL, 1, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(9, 4, 0, 0, 'MLK Day', 'yearly', '2019-01-21', '00:00:00', '2019-01-21', '23:59:59', NULL, 1, 3, 1, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(10, 4, 0, 0, 'Memorial Day', 'yearly', '2019-05-27', '00:00:00', '2019-05-27', '23:59:59', NULL, 1, -1, 5, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(11, 4, 0, 0, 'Independence Day (4th of July)', 'yearly', '2019-07-04', '00:00:00', '2019-07-04', '23:59:59', NULL, 4, NULL, 7, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(12, 4, 0, 0, 'Labor Day', 'yearly', '2019-09-02', '00:00:00', '2019-09-02', '23:59:59', NULL, 1, 1, 9, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(13, 4, 0, 0, 'Indigenous Peoples'' Day (Whodat Columbus)', 'yearly', '2019-10-14', '00:00:00', '2019-10-14', '23:59:59', NULL, 1, 2, 10, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(14, 4, 0, 0, 'Veterans Day', 'yearly', '2019-11-11', '00:00:00', '2019-11-11', '23:59:59', NULL, 11, NULL, 11, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(15, 4, 0, 0, 'Thanksgiving Day', 'yearly', '2019-11-28', '00:00:00', '2019-11-28', '23:59:59', NULL, 4, 4, 11, '0000-00-00 00:00:00', '2025-12-10 05:54:55'),
(16, 4, 0, 0, 'Christmas Day', 'yearly', '2019-11-25', '00:00:00', '2019-11-25', '23:59:59', NULL, 25, NULL, 12, '0000-00-00 00:00:00', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_sequence`
--

CREATE TABLE `ostqr_sequence` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL,
  `flags` int(10) unsigned DEFAULT NULL,
  `next` bigint(20) unsigned NOT NULL DEFAULT 1,
  `increment` int(11) DEFAULT 1,
  `padding` char(1) DEFAULT '0',
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_sequence`
--

INSERT INTO `ostqr_sequence` VALUES
(1, 'General Tickets', 1, 1, 1, '0', '0000-00-00 00:00:00'),
(2, 'Tasks Sequence', 1, 1, 1, '0', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_session`
--

CREATE TABLE `ostqr_session` (
  `session_id` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `session_data` blob DEFAULT NULL,
  `session_expire` datetime DEFAULT NULL,
  `session_updated` datetime DEFAULT NULL,
  `user_id` varchar(16) NOT NULL DEFAULT '0' COMMENT 'osTicket staff/client ID',
  `user_ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `updated` (`session_updated`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ostqr_session`
--

INSERT INTO `ostqr_session` VALUES
('04dfhmvmcm9l2en9gef2a8an7s', 'csrf|a:2:{s:5:"token";s:40:"9675c76c65833b3fd7b9fcc7fcae16819275dfd5";s:4:"time";i:1765348808;}', '2025-12-11 06:40:08', '2025-12-10 06:40:08', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('099ke2dk7vednetmmfa27euum3', 'csrf|a:2:{s:5:"token";s:40:"45c324454c3178e44a2aeca648c4924ca20f1757";s:4:"time";i:1765347641;}', '2025-12-11 06:20:41', '2025-12-10 06:20:41', '0', '152.39.201.162', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1'),
('0eq6uvdot6phrpbi1chme0h44o', 'csrf|a:2:{s:5:"token";s:40:"6dc59b1f75c9ea44278dad3191e7c41b1854b867";s:4:"time";i:1765348715;}', '2025-12-11 06:38:35', '2025-12-10 06:38:35', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('0f0co1ekmgcopj6chto8cu27vd', 'csrf|a:2:{s:5:"token";s:40:"d52237122e597add24915b8853e20721ec23a477";s:4:"time";i:1765349317;}', '2025-12-11 06:48:37', '2025-12-10 06:48:38', '0', '34.132.84.222', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1467.0 Safari/537.36'),
('0t58onpph2vtu03tcpgonomtvj', 'csrf|a:2:{s:5:"token";s:40:"3a3d4df1337b62ac8de3cb1b3a3d79ca358ccebc";s:4:"time";i:1765384051;}', '2025-12-11 16:27:31', '2025-12-10 16:27:31', '0', '202.120.37.109', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/5d7.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36'),
('15mai2rkjqpq9r6t9pl62o45d4', 'csrf|a:2:{s:5:"token";s:40:"02bdeb6b8418efcca06c0faeed62303f569e8031";s:4:"time";i:1765415702;}', '2025-12-12 01:14:28', '2025-12-11 01:15:02', '0', '34.116.192.240', 'Mozilla/5.0 (iPhone13,2; U; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1'),
('1ui98uapuvj7q9gpo50oedoqqp', 'csrf|a:2:{s:5:"token";s:40:"b18a6bc56a3fed6b2f0fa228d639c560b13aac66";s:4:"time";i:1765348373;}', '2025-12-11 06:32:53', '2025-12-10 06:32:53', '0', '139.99.237.35', ''),
('2dhtsmaooa3pkfl8r6fvgh6m8m', 'csrf|a:2:{s:5:"token";s:40:"71bb6ade9b9bf28bb890818d5a87c34a8d0e295f";s:4:"time";i:1765348584;}', '2025-12-11 06:36:24', '2025-12-10 06:36:24', '0', '192.175.111.244', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('2k2msc0rqi5j7tr7k6ufrnnrae', 'csrf|a:2:{s:5:"token";s:40:"fd528ccfda98afca42f3c354b61c56780fab0aa1";s:4:"time";i:1765375296;}', '2025-12-11 14:01:36', '2025-12-10 14:01:36', '0', '91.84.74.250', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36'),
('2ni6bek75t5j165dpibrkpnour', 'csrf|a:2:{s:5:"token";s:40:"e1d24eb774d9fcb14bf263c9007b94dc3c16eea3";s:4:"time";i:1765417428;}_client|a:1:{s:4:"auth";a:1:{s:4:"dest";s:17:"/tickets.php?id=5";}}_auth|a:1:{s:4:"user";N;}', '2025-12-12 01:43:48', '2025-12-11 01:43:48', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('2ocpudgh4fimc9q1uccov7e63a', 'csrf|a:2:{s:5:"token";s:40:"713e37bcd0ce06d61494f963cb6a7f2ae4845569";s:4:"time";i:1765359851;}cfg:core|a:1:{s:11:"db_timezone";s:3:"UTC";}_auth|a:1:{s:4:"user";a:2:{s:2:"id";i:3;s:3:"key";s:47:"authtoken:o3t5heccbc87e4b5ce2fe28308fd9f2a7baf3";}}:token|a:1:{s:6:"client";s:76:"0c0314362f1e7d7038c68280a27afacf:1765358624:7e321012010abbfbd3cea3ccd00c1162";}TIME_BOMB|i:1765359787;_client|a:1:{s:4:"auth";a:1:{s:4:"dest";s:17:"/tickets.php?id=5";}}', '2025-12-11 08:43:33', '2025-12-10 09:44:11', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
('2pbmiikt849pg61pnainsu9fe1', 'csrf|a:2:{s:5:"token";s:40:"33ac86cc92b7a56b33ff044a2ecdecef4dade6fa";s:4:"time";i:1765347605;}', '2025-12-11 06:20:05', '2025-12-10 06:20:05', '0', '161.123.85.119', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1'),
('2vio7hah5f0mhjoo09cnaj1trs', 'csrf|N;', '2025-12-11 06:36:22', '2025-12-10 06:36:22', '0', '192.175.111.241', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('328ml175jtmdqij9bjsvg7vpli', 'csrf|a:2:{s:5:"token";s:40:"514a0b8f4eb78ebde4da57ad56d90da4b800f5a1";s:4:"time";i:1765346467;}', '2025-12-11 06:01:07', '2025-12-10 06:01:07', '0', '2a06:98c0:3600::103', ''),
('3digvd9cpula8rjelods2jggit', 'csrf|a:2:{s:5:"token";s:40:"2a03c44f76054f0e48c2e7398256651136ba71fa";s:4:"time";i:1765346535;}', '2025-12-11 06:02:15', '2025-12-10 06:02:15', '0', '192.64.113.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0'),
('3sdt31g2c73o7snq8kfv0f22cm', 'csrf|N;', '2025-12-11 14:14:21', '2025-12-10 14:14:21', '0', '134.209.82.95', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
('42tqg6bjd55m79t913e7t11f4c', 'csrf|N;', '2025-12-11 06:36:16', '2025-12-10 06:36:16', '0', '192.175.111.237', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('4nn2r100rs21n0e6da7k293pi0', 'csrf|a:2:{s:5:"token";s:40:"5d029a48e73aaf64d7ecaf6085e5240d5bbe0786";s:4:"time";i:1765380709;}', '2025-12-11 15:31:49', '2025-12-10 15:31:49', '0', '65.87.7.112', 'Mozilla/5.0 (compatible; Let''s Encrypt validation server; +https://www.letsencrypt.org)'),
('4p8a0eg8vtsg2097r2fhbni1v6', 'csrf|N;', '2025-12-11 15:31:51', '2025-12-10 15:31:51', '0', '65.87.7.112', 'Mozilla/5.0 (compatible; Let''s Encrypt validation server; +https://www.letsencrypt.org)'),
('52d5ja9a0cl20jl0eeht8rptb2', 'csrf|a:2:{s:5:"token";s:40:"ef6719ef08d96ca039ab697d5e16881fdff530d8";s:4:"time";i:1765347617;}', '2025-12-11 06:20:17', '2025-12-10 06:20:17', '0', '86.106.177.130', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1'),
('54a40grssdqgttgjnqmug7pu0i', 'csrf|a:2:{s:5:"token";s:40:"4027d64e34e74779993524639fd5a600e0546c6d";s:4:"time";i:1765415645;}', '2025-12-12 01:14:03', '2025-12-11 01:14:05', '0', '205.169.39.93', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36'),
('58ai1iv3qm6k2p78p33iv4pvv4', 'csrf|N;', '2025-12-11 07:08:35', '2025-12-10 07:08:35', '0', '44.243.72.22', 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1'),
('5gfa5dggclh0h286kofotdr6bq', 'csrf|a:2:{s:5:"token";s:40:"25208608a7f26686287e959078655105d5451070";s:4:"time";i:1765357908;}_client|a:1:{s:4:"auth";a:1:{s:4:"dest";s:17:"/tickets.php?id=2";}}_auth|a:1:{s:4:"user";N;}', '2025-12-11 09:11:48', '2025-12-10 09:11:48', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
('5h5f125i99rksi2ibgn90oqeuk', 'csrf|a:2:{s:5:"token";s:40:"6b2fb4cc8ca2339819896f7c6832aafb9acc436b";s:4:"time";i:1765348782;}', '2025-12-11 06:39:42', '2025-12-10 06:39:42', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('5pu2tpkp6sos9hm1281bnd08p6', 'csrf|a:2:{s:5:"token";s:40:"279bf46c72fbb6ec83e13bce17ee34a6a944d8a5";s:4:"time";i:1765346461;}', '2025-12-11 06:01:01', '2025-12-10 06:01:01', '0', '2a06:98c0:3600::103', ''),
('662lo8ggeh0059dje2rihu4vt4', 'csrf|a:2:{s:5:"token";s:40:"3dc0c1e2de875e389bf867c650413aeac432ff07";s:4:"time";i:1765348587;}', '2025-12-11 06:36:28', '2025-12-10 06:36:28', '0', '192.175.111.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('683h3t55qhuk0mqvog9a45f88r', 'csrf|a:2:{s:5:"token";s:40:"dbdadf0a315ef337901370b1b991c6ecc25ef675";s:4:"time";i:1765379665;}', '2025-12-11 15:14:25', '2025-12-10 15:14:25', '0', '149.57.180.191', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0'),
('6h7hdnqbsfia2336rf6v3vo573', 'csrf|a:2:{s:5:"token";s:40:"ae968617d5a54c144cc1e4a4a4c7ad41c4eb45c6";s:4:"time";i:1765417579;}', '2025-12-12 01:46:19', '2025-12-11 01:46:19', '0', '44.248.147.124', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36 Assetnote/1.0.0'),
('6ngegd37s9mqm6em7kqb2l6qk3', 'csrf|a:2:{s:5:"token";s:40:"d38dd0b44c089db807286982d7c4349242139dcc";s:4:"time";i:1765348581;}', '2025-12-11 06:36:21', '2025-12-10 06:36:21', '0', '64.15.129.102', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('7a4j2kf02orfg56sq7ucop85at', 'csrf|N;', '2025-12-11 06:36:19', '2025-12-10 06:36:19', '0', '64.15.129.126', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('7i659r1b5qpun7e1la8o8lmnea', 'csrf|a:2:{s:5:"token";s:40:"f256567639ab5581fd0a4a9196bab0fa05ae4773";s:4:"time";i:1765425014;}_staff|a:1:{s:4:"auth";a:2:{s:4:"dest";s:14:"/scp/index.php";s:3:"msg";s:23:"Authentication Required";}}_auth|a:2:{s:5:"staff";N;s:4:"user";N;}cfg:core|a:1:{s:11:"db_timezone";s:3:"UTC";}', '2025-12-11 06:13:10', '2025-12-11 03:50:14', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0'),
('7pt4fb1adeske0rgmn76ohrplc', 'csrf|a:2:{s:5:"token";s:40:"0f5556a32043cd8732f72e6ba2f5b1f87d9ea739";s:4:"time";i:1765348707;}_auth|a:1:{s:4:"user";N;}', '2025-12-11 06:38:27', '2025-12-10 06:38:27', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('874tbhc0ibhuerh5671quita0t', 'csrf|a:2:{s:5:"token";s:40:"cce2fd3ddbbc41e54bf8e3cbab30e9ebb7932525";s:4:"time";i:1765346535;}', '2025-12-11 06:02:15', '2025-12-10 06:02:15', '0', '192.64.113.146', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'),
('8de7te3hcf2c85duuijg891bo9', 'csrf|a:2:{s:5:"token";s:40:"9ae9adeb522ba77ea73c7e502ff5c3f3a722640d";s:4:"time";i:1765346536;}', '2025-12-11 06:02:16', '2025-12-10 06:02:16', '0', '192.64.113.146', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0'),
('8ek9ppvrrpcvgm1b8ntvqgum9n', 'csrf|a:2:{s:5:"token";s:40:"29947fa88c576dcaac1ab4d39ce0e65a5840f37a";s:4:"time";i:1765417924;}', '2025-12-12 01:52:04', '2025-12-11 01:52:04', '0', '44.248.147.124', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36 Assetnote/1.0.0'),
('9qbgri0l5aq1i5vii84pkidea9', 'csrf|a:2:{s:5:"token";s:40:"c562698d9145e8756d0aca5534bb3dd105e3bb3b";s:4:"time";i:1765386670;}', '2025-12-11 17:11:10', '2025-12-10 17:11:10', '0', '149.57.180.119', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'),
('9qnt4vj6lgno827mqq7ks72q1o', 'csrf|a:2:{s:5:"token";s:40:"8d7676d747ac99f49287aac6de158c7f06b99734";s:4:"time";i:1765380709;}', '2025-12-11 15:31:49', '2025-12-10 15:31:49', '0', '65.87.7.112', 'Mozilla/5.0 (compatible; Let''s Encrypt validation server; +https://www.letsencrypt.org)'),
('a4cjg2i28umevp8ut5ldi5bddc', 'csrf|a:2:{s:5:"token";s:40:"a3ec82517ad8a627e3ac8492c8cd114da2d8716e";s:4:"time";i:1765346535;}', '2025-12-11 06:02:15', '2025-12-10 06:02:15', '0', '192.64.113.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'),
('acul28jj7c2ljhkemdt6k6u64m', 'csrf|a:2:{s:5:"token";s:40:"e915b45b744ac85676c83cf9e38f0d7f874d001e";s:4:"time";i:1765417489;}_client|a:1:{s:4:"auth";a:1:{s:4:"dest";s:17:"/tickets.php?id=4";}}_auth|a:1:{s:4:"user";N;}', '2025-12-12 01:44:49', '2025-12-11 01:44:49', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('ams2h7lk6ks4g0mbqjec1ummm2', 'csrf|a:2:{s:5:"token";s:40:"ba7d77c4bec542a1a0faac0b56515195cf3c55d6";s:4:"time";i:1765351299;}', '2025-12-11 07:21:39', '2025-12-10 07:21:39', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('bco3ujsa3mdh2imaqql9a49mg5', 'csrf|a:2:{s:5:"token";s:40:"d377af6b5ca7c97443d8cd65895b26ca7f7d51f1";s:4:"time";i:1765359745;}_auth|a:1:{s:4:"user";a:2:{s:2:"id";i:3;s:3:"key";s:47:"authtoken:o3t5heccbc87e4b5ce2fe28308fd9f2a7baf3";}}:token|a:1:{s:6:"client";s:76:"81704e60983ef610c2152c14cbfb6e5f:1765359744:dab53e22fc1ca14f881c22cc8762f863";}TIME_BOMB|i:1765359754;cfg:core|a:1:{s:11:"db_timezone";s:3:"UTC";}', '2025-12-11 09:42:24', '2025-12-10 09:42:25', '0', '1.37.67.201', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('bcutsn9hb91g5k7322evenuo3a', 'csrf|a:2:{s:5:"token";s:40:"54fc86774b29cd891e1fe95bae0951c033857524";s:4:"time";i:1765353002;}_auth|a:1:{s:4:"user";a:2:{s:2:"id";i:2;s:3:"key";s:47:"authtoken:o2t2hc81e728d9d4c2f636f067f89cc14862c";}}:token|a:1:{s:6:"client";s:76:"1a976c5cc0d64a2507a6a03625eb9d38:1765352994:9edac349bf5dfd805dae138e880f5bc1";}TIME_BOMB|i:1765353004;cfg:core|a:1:{s:11:"db_timezone";s:3:"UTC";}', '2025-12-11 07:49:54', '2025-12-10 07:50:02', '0', '1.37.67.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
('bgkgbtuhfkrqiblkrflhnlqcoq', 'csrf|a:2:{s:5:"token";s:40:"6de7632b660d4ca4d87152fc5e5d6b75d5a636ed";s:4:"time";i:1765347607;}', '2025-12-11 06:20:07', '2025-12-10 06:20:07', '0', '104.253.247.59', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1'),
('c4m9jhhc331nh0ot8u96qgmt9t', 'csrf|a:2:{s:5:"token";s:40:"f5ef55c5635df7a2dd3783be91779ffe43d48437";s:4:"time";i:1765348580;}', '2025-12-11 06:36:20', '2025-12-10 06:36:20', '0', '192.175.111.246', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('cmc8gg2gqfrrj2n6rk8oeig7at', 'csrf|a:2:{s:5:"token";s:40:"319858e0880217d4b2f60a9257b69b5c9fedc6ed";s:4:"time";i:1765348814;}', '2025-12-11 06:40:15', '2025-12-10 06:40:15', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('d66abd8fs88imk2urrn53v43cm', 'csrf|a:2:{s:5:"token";s:40:"83b0efc21ebf146097e6b65e26acd038239369de";s:4:"time";i:1765356914;}', '2025-12-11 08:55:14', '2025-12-10 08:55:14', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('dt9r6kmbjlerm7oo8i2s88bq2u', 'csrf|a:2:{s:5:"token";s:40:"ca1864759d1bf79219ead24be7404a0e3877e87f";s:4:"time";i:1765350371;}', '2025-12-11 07:06:11', '2025-12-10 07:06:11', '0', '104.37.46.213', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.35/36 Safari/537.36'),
('e2atp3eigub3ulclmassg4je5v', 'csrf|a:2:{s:5:"token";s:40:"34851c36ed6752f6121b0498067baa9cbb0f6c1f";s:4:"time";i:1765348576;}', '2025-12-11 06:36:16', '2025-12-10 06:36:16', '0', '64.15.129.101', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('ef1karfeamoc29185hd1ja5jcu', 'csrf|N;', '2025-12-11 17:02:26', '2025-12-10 17:02:26', '0', '34.125.195.0', 'Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)'),
('ejfrk6imm5eirtn6cdikfi8893', 'csrf|a:2:{s:5:"token";s:40:"3c57cfa854c0fc79a42c28703d6639edceba0970";s:4:"time";i:1765353994;}_auth|a:1:{s:5:"staff";N;}', '2025-12-11 08:06:34', '2025-12-10 08:06:34', '0', '100.29.130.36', 'Iframely/1.3.1 (+https://iframely.com/docs/about) Atlassian'),
('eumr1dcfgfkonk1rk88cd8lum2', 'csrf|a:2:{s:5:"token";s:40:"9b1c536590e803486011e9b3c0989e5f1b9400ff";s:4:"time";i:1765376063;}', '2025-12-11 14:14:23', '2025-12-10 14:14:23', '0', '134.209.82.95', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
('fk95ijlglhfl8vkjslccmqfnmh', 'csrf|a:2:{s:5:"token";s:40:"febe109708f45f979d56ba1834c78f240d09ef7d";s:4:"time";i:1765348583;}', '2025-12-11 06:36:23', '2025-12-10 06:36:23', '0', '192.175.111.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('fo8hjj04rjaaoe5cnltebj12cq', 'csrf|a:2:{s:5:"token";s:40:"73add6b79915590252b4c1d6ff1c72b714d6c881";s:4:"time";i:1765380709;}', '2025-12-11 15:31:49', '2025-12-10 15:31:49', '0', '65.87.7.112', 'Mozilla/5.0 (compatible; Let''s Encrypt validation server; +https://www.letsencrypt.org)'),
('fptsg57div5srg7k9htbq4i9hd', 'csrf|a:2:{s:5:"token";s:40:"a890144c575e5ee7214bbbc95948bd987b22bfd2";s:4:"time";i:1765351439;}_auth|a:1:{s:5:"staff";N;}', '2025-12-11 07:23:59', '2025-12-10 07:23:59', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('g2q7ktl3dl0jfoeq0vs1dlfq0f', 'csrf|a:2:{s:5:"token";s:40:"7425e11ed08c69fb773e9ef500dfc23a3d020afb";s:4:"time";i:1765384054;}', '2025-12-11 16:27:34', '2025-12-10 16:27:34', '0', '202.120.37.109', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/5d7.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36'),
('gdd2nesodovmkh88m905mf0v7l', 'csrf|a:2:{s:5:"token";s:40:"6a9c4b75a58f54c7dd2136f62b1ecc0e91992bdf";s:4:"time";i:1765352452;}', '2025-12-11 07:40:53', '2025-12-10 07:40:53', '0', '142.252.248.140', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.35/36 Safari/537.36'),
('h2a7bivbgafd6tsfrvgjpqiv1i', 'csrf|a:2:{s:5:"token";s:40:"14aa6326800909998ef04613e1832fb306bf6353";s:4:"time";i:1765417549;}_client|a:1:{s:4:"auth";a:1:{s:4:"dest";s:17:"/tickets.php?id=5";}}_auth|a:1:{s:4:"user";N;}', '2025-12-12 01:45:49', '2025-12-11 01:45:49', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('h34eckdeev436j104elpuas279', 'csrf|a:2:{s:5:"token";s:40:"baffedfff61d42ceac17914ad7563d7b1083efcb";s:4:"time";i:1765374832;}', '2025-12-11 13:53:52', '2025-12-10 13:53:52', '0', '34.143.189.183', 'curl/7.83.1'),
('h3jt11v6unl1k0lp7km8q4bohm', 'csrf|a:2:{s:5:"token";s:40:"82eb21d2daab2f57a94dd510f862df848552892e";s:4:"time";i:1765348368;}', '2025-12-11 06:32:48', '2025-12-10 06:32:48', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('i5a8bk31sa8guv1gt2cde19a9p', 'csrf|a:2:{s:5:"token";s:40:"e69f6058a6bd0902e3462912cb403b7253557cc1";s:4:"time";i:1765350515;}', '2025-12-11 07:08:35', '2025-12-10 07:08:35', '0', '44.243.72.22', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36'),
('i5eetr7fuh7ilsdtv8f7gtdl4i', 'csrf|a:2:{s:5:"token";s:40:"9ba9d7438e01db0531f76f51c2d80b7a282d9796";s:4:"time";i:1765350515;}', '2025-12-11 07:08:35', '2025-12-10 07:08:35', '0', '44.243.72.22', 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1'),
('iidfaf291qimofl8t45h3u2jnk', 'csrf|a:2:{s:5:"token";s:40:"9dff4e42429c70969674314cb179ff45c9db0acf";s:4:"time";i:1765351292;}', '2025-12-11 07:21:32', '2025-12-10 07:21:32', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('jvpk5gk4c1mbi0sb30mfu46ot4', 'csrf|a:2:{s:5:"token";s:40:"3261ac792394ab0565f0833c2ed4d77ff8a6cad5";s:4:"time";i:1765415633;}', '2025-12-12 01:13:51', '2025-12-11 01:13:53', '0', '205.169.39.93', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36'),
('kd6uge4q945hsnd4cefenql18j', 'csrf|a:2:{s:5:"token";s:40:"bee80933c2e6621148740837a29b02cf8c6b9c90";s:4:"time";i:1765348587;}', '2025-12-11 06:36:27', '2025-12-10 06:36:27', '0', '64.15.129.109', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('lf7nm9it9spjlamft98ccr64s4', 'csrf|a:2:{s:5:"token";s:40:"ad4c83bedc447d218323ef6a709cf3945bfaf9af";s:4:"time";i:1765353970;}', '2025-12-11 08:06:10', '2025-12-10 08:06:10', '0', '34.198.221.238', 'Iframely/1.3.1 (+https://iframely.com/docs/about) Atlassian'),
('n1pd3c88gf2ag4mhmdjuvivobg', 'csrf|a:2:{s:5:"token";s:40:"f88fa2e05bc63a7ab4339c3bf0e4cde8a3e34bcb";s:4:"time";i:1765357553;}', '2025-12-11 09:05:53', '2025-12-10 09:05:53', '0', '23.228.132.132', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'),
('n49jda48ecr1it9pismt13sep3', 'csrf|a:2:{s:5:"token";s:40:"298541e62dee612b395d38dd8ca38c6eb4148662";s:4:"time";i:1765387169;}', '2025-12-11 17:19:30', '2025-12-10 17:19:30', '0', '34.38.57.170', 'Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)'),
('n62ir7c1qhbkt3at6giii9rkp1', 'csrf|a:2:{s:5:"token";s:40:"405b2c2adc1bc0cf4174e5c63a220e2a7c6e03b6";s:4:"time";i:1765386147;}', '2025-12-11 17:02:27', '2025-12-10 17:02:27', '0', '34.125.195.0', 'Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)'),
('netghmmf0lhg7dsmfsasgvo6kr', 'csrf|a:2:{s:5:"token";s:40:"e59b28b8e829ccafc72007479bae0506aa70f486";s:4:"time";i:1765348738;}', '2025-12-11 06:38:58', '2025-12-10 06:38:58', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('nffconjg9p2vr856d0pq0gp5qi', 'csrf|a:2:{s:5:"token";s:40:"2f09d8e985228b002d6a9a97a540e10103696749";s:4:"time";i:1765351251;}', '2025-12-11 07:20:51', '2025-12-10 07:20:51', '0', '154.47.78.20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.35/36 Safari/537.36'),
('njvqrvtmrhjsj8ech872fea0ve', 'csrf|a:2:{s:5:"token";s:40:"532f999c6b02eb9b478769150f252a40e1816e20";s:4:"time";i:1765347733;}_auth|a:2:{s:4:"user";N;s:5:"staff";N;}_staff|a:1:{s:4:"auth";a:2:{s:4:"dest";s:14:"/scp/index.php";s:3:"msg";s:23:"Authentication Required";}}', '2025-12-11 06:21:38', '2025-12-10 06:22:13', '0', '74.7.243.221', 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)'),
('nqdgp7vk3qb69sbbd56ete9rua', 'csrf|a:2:{s:5:"token";s:40:"1f8b285763b661f16599bddb0ac98a2445157dab";s:4:"time";i:1765348582;}', '2025-12-11 06:36:22', '2025-12-10 06:36:22', '0', '64.15.129.111', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('o2ade5vs9o7elidoukq7910i8b', 'csrf|N;', '2025-12-11 06:36:15', '2025-12-10 06:36:15', '0', '192.175.111.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('o2i0knblnmj0vdo06mp8safk7e', 'csrf|a:2:{s:5:"token";s:40:"480cab8e62fa05d2c43d66b5b57b18fbb8b050c9";s:4:"time";i:1765357531;}', '2025-12-11 09:05:22', '2025-12-10 09:05:31', '0', '209.141.121.196', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
('o3rf1ib0kg1hvj9rup36lj8411', 'csrf|a:2:{s:5:"token";s:40:"eff794fcfe2bb51d2fc4500a459df823d176f501";s:4:"time";i:1765348824;}', '2025-12-11 06:40:24', '2025-12-10 06:40:24', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('oppren9fn9c9rqlpvriq4lb3dp', 'csrf|a:2:{s:5:"token";s:40:"301dff430f5904c92e1e21863e8e7b03c2d4e327";s:4:"time";i:1765348691;}_auth|a:1:{s:4:"user";N;}', '2025-12-11 06:38:11', '2025-12-10 06:38:11', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('p134cigvcth0kcphg3774a05h4', 'csrf|a:2:{s:5:"token";s:40:"41b5cc5a74b60466ce7dcf9da87f9919ce3077cf";s:4:"time";i:1765348609;}', '2025-12-11 06:36:49', '2025-12-10 06:36:49', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('pg1l40mks168tn6lrdbpbgi3eh', 'csrf|a:2:{s:5:"token";s:40:"ee0fba67fe75d09c9ce198954e7326dbb4e4ebf4";s:4:"time";i:1765346461;}', '2025-12-11 06:01:01', '2025-12-10 06:01:01', '0', '2a06:98c0:3600::103', ''),
('q8ahq1shvmd07geob5rh6hirrr', 'csrf|a:2:{s:5:"token";s:40:"9d7a02ad2ca2ce1cb0ebb7556a2e522ca9155903";s:4:"time";i:1765348587;}', '2025-12-11 06:36:27', '2025-12-10 06:36:27', '0', '192.175.111.252', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('re7fdogst94lj0lqk9srk66cr1', 'csrf|a:2:{s:5:"token";s:40:"545cd91de7b95a5c5036233c3e16182f687ae6cc";s:4:"time";i:1765417550;}_client|a:1:{s:4:"auth";a:1:{s:4:"dest";s:12:"/tickets.php";}}_auth|a:1:{s:4:"user";N;}', '2025-12-12 01:45:50', '2025-12-11 01:45:50', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('rkdabkhrd7m5mcu1fsnuri89q2', 'csrf|N;', '2025-12-11 07:08:35', '2025-12-10 07:08:35', '0', '44.243.72.22', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36'),
('ro1nsmfupa9kq1kjiq70s6893o', 'csrf|a:2:{s:5:"token";s:40:"426a8477a9e077cd31bda2427f3b6149611dd113";s:4:"time";i:1765348490;}_auth|a:2:{s:4:"user";N;s:5:"staff";N;}_staff|a:1:{s:4:"auth";a:2:{s:4:"dest";s:14:"/scp/index.php";s:3:"msg";s:23:"Authentication Required";}}', '2025-12-11 06:34:15', '2025-12-10 06:34:50', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246'),
('rs51sbp8d1r026cgupnjhkd0sg', 'csrf|a:2:{s:5:"token";s:40:"a9ea69b49e7781275e82d7fd1bd92217f5fd76ea";s:4:"time";i:1765359747;}_auth|a:1:{s:4:"user";a:2:{s:2:"id";i:3;s:3:"key";s:47:"authtoken:o3t5heccbc87e4b5ce2fe28308fd9f2a7baf3";}}:token|a:1:{s:6:"client";s:76:"1369cd6beb9141b607ffc137a2fb1241:1765359747:dab53e22fc1ca14f881c22cc8762f863";}TIME_BOMB|i:1765359757;cfg:core|a:1:{s:11:"db_timezone";s:3:"UTC";}', '2025-12-11 09:42:27', '2025-12-10 09:42:27', '0', '1.37.67.201', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
('ru3a9qsdb9i834kuplho4ncc76', 'csrf|N;_staff|a:1:{s:4:"auth";a:2:{s:4:"dest";s:14:"/scp/index.php";s:3:"msg";s:23:"Authentication Required";}}', '2025-12-11 07:23:58', '2025-12-10 07:23:58', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('s56r15t82qd38fhqcq15sdasht', 'csrf|a:2:{s:5:"token";s:40:"7d91d0498bf09640d679e0fcb094917a5edba2e0";s:4:"time";i:1765348577;}', '2025-12-11 06:36:17', '2025-12-10 06:36:17', '0', '64.15.129.102', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('s61ihc613qppi5fgq7lmr46o0m', 'csrf|a:2:{s:5:"token";s:40:"d8aba4d353002d482001e09390bdf2cbecbce33c";s:4:"time";i:1765350523;}', '2025-12-11 07:08:43', '2025-12-10 07:08:43', '0', '35.92.175.42', 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1'),
('s8ositflki9gg31mc5ov7ugvbo', 'csrf|a:2:{s:5:"token";s:40:"8453214609b9b28c24320eb29500d8314f9a1466";s:4:"time";i:1765351390;}_auth|a:1:{s:5:"staff";N;}', '2025-12-11 07:23:11', '2025-12-10 07:23:11', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('skrbjb4sah7cadjk9kr7bv1c6i', 'csrf|a:2:{s:5:"token";s:40:"13edf9c6aeeb429fa1c059885982f76d570f7c1b";s:4:"time";i:1765346466;}', '2025-12-11 06:01:06', '2025-12-10 06:01:06', '0', '2a06:98c0:3600::103', ''),
('ss71a4bav4kjigkbtjgo57aqet', 'csrf|a:2:{s:5:"token";s:40:"f710f48df4631b961e05624d7bc3c9eee3de0976";s:4:"time";i:1765424539;}_staff|a:1:{s:4:"auth";a:2:{s:4:"dest";s:25:"/scp/settings.php?t=users";s:3:"msg";s:23:"Authentication Required";}}_auth|a:2:{s:5:"staff";N;s:4:"user";N;}', '2025-12-12 01:40:52', '2025-12-11 03:42:19', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('tertrvo86kmv1tmih79c7pbtk1', 'csrf|a:2:{s:5:"token";s:40:"b8bdff249237f02f8e4e4a2073cc91540de7d9a8";s:4:"time";i:1765381447;}', '2025-12-11 15:44:07', '2025-12-10 15:44:07', '0', '149.57.180.158', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0'),
('uhnsscqor1panedtck6ok2c1pv', 'csrf|a:2:{s:5:"token";s:40:"d3bb61a90da7b1aaf6826f653ec0ee6e2e168879";s:4:"time";i:1765348599;}', '2025-12-11 06:36:39', '2025-12-10 06:36:39', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('urgeeefcs6h0l26d795dq7uik9', 'csrf|a:2:{s:5:"token";s:40:"01d68f9e07a454f51d8222df0cab1aff810d82a9";s:4:"time";i:1765350519;}', '2025-12-11 07:08:39', '2025-12-10 07:08:39', '0', '35.92.175.42', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36'),
('uroigermv761k1noklv096uiht', 'csrf|a:2:{s:5:"token";s:40:"5f1dbabda079734b320038a84a7a494fed8443e1";s:4:"time";i:1765351496;}_staff|a:1:{s:4:"auth";a:2:{s:4:"dest";s:14:"/scp/index.php";s:3:"msg";s:23:"Authentication Required";}}_auth|a:1:{s:5:"staff";N;}', '2025-12-11 07:24:55', '2025-12-10 07:24:56', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('utpc5tm536kphcjrieb815opeo', 'csrf|a:2:{s:5:"token";s:40:"d87a549e5c3d278828b9054ccfe3711faeb11f4f";s:4:"time";i:1765417368;}', '2025-12-12 01:42:48', '2025-12-11 01:42:48', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'),
('vnotqcrjb46vda1kuk9c24k7d1', 'csrf|a:2:{s:5:"token";s:40:"b6d327f5c2f0384655d7af48aa6bc05e63d25669";s:4:"time";i:1765351401;}_auth|a:1:{s:5:"staff";N;}', '2025-12-11 07:23:21', '2025-12-10 07:23:21', '0', '139.99.237.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'),
('vt4ka3f9r9geds2cg0ltiorgm9', 'csrf|a:2:{s:5:"token";s:40:"bab42380f80ce6a2311fdf18c0d589cc53354d38";s:4:"time";i:1765388680;}', '2025-12-11 17:44:40', '2025-12-10 17:44:40', '0', '149.57.180.22', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0'),
('vu7llcl16m2thtp6ii09vmj3v0', 'csrf|a:2:{s:5:"token";s:40:"42fcf154e62c709998aa494586ea60eda16d7a0f";s:4:"time";i:1765417428;}', '2025-12-12 01:43:48', '2025-12-11 01:43:48', '0', '180.190.23.94', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_sla`
--

CREATE TABLE `ostqr_sla` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 3,
  `grace_period` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_sla`
--

INSERT INTO `ostqr_sla` VALUES
(1, 0, 3, 18, 'Default SLA', NULL, '2025-12-10 05:54:55', '2025-12-10 05:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_staff`
--

CREATE TABLE `ostqr_staff` (
  `staff_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned NOT NULL DEFAULT 0,
  `username` varchar(32) NOT NULL DEFAULT '',
  `firstname` varchar(32) DEFAULT NULL,
  `lastname` varchar(32) DEFAULT NULL,
  `passwd` varchar(128) DEFAULT NULL,
  `backend` varchar(32) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(24) NOT NULL DEFAULT '',
  `phone_ext` varchar(6) DEFAULT NULL,
  `mobile` varchar(24) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `lang` varchar(16) DEFAULT NULL,
  `timezone` varchar(64) DEFAULT NULL,
  `locale` varchar(16) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT 1,
  `isadmin` tinyint(1) NOT NULL DEFAULT 0,
  `isvisible` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `onvacation` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `assigned_only` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `show_assigned_tickets` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `change_passwd` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `max_page_size` int(11) unsigned NOT NULL DEFAULT 0,
  `auto_refresh_rate` int(10) unsigned NOT NULL DEFAULT 0,
  `default_signature_type` enum('none','mine','dept') NOT NULL DEFAULT 'none',
  `default_paper_size` enum('Letter','Legal','Ledger','A4','A3') NOT NULL DEFAULT 'Letter',
  `extra` text DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `passwdreset` datetime DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `username` (`username`),
  KEY `dept_id` (`dept_id`),
  KEY `issuperuser` (`isadmin`),
  KEY `isactive` (`isactive`),
  KEY `onvacation` (`onvacation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_staff`
--

INSERT INTO `ostqr_staff` VALUES
(1, 1, 1, 'y0Tnc6zhZB51Dg', 'System', 'Administrator', '$2a$08$v2A2v82/M2.3jTmJq1kF3eaF3MWQ9lZmpkJjzR.dNyFvHepv23mf6', NULL, 'admin@apexsinc.com', '', NULL, '', '', NULL, NULL, NULL, NULL, 1, 1, 0, 0, 0, 0, 0, 25, 0, 'none', 'Letter', '{"browser_lang":"en_US","def_assn_role":true}', '{"user.create":1,"user.delete":1,"user.edit":1,"user.manage":1,"user.dir":1,"org.create":1,"org.delete":1,"org.edit":1,"faq.manage":1,"visibility.agents":1,"emails.banlist":1,"visibility.departments":1}', '2025-12-10 05:54:55', '2025-12-10 09:09:47', '2025-12-10 05:54:55', '2025-12-10 09:09:47'),
(2, 1, 1, 'janasco', 'Jaymar', 'Anasco', '$2a$08$1ZJiAA2lFe8JhuxUB5CbzepUog6zSyPbJJPXiZ5C3IX7DuiqmpLay', NULL, 'janasco@apexsinc.com', '', NULL, '09173129336', '<p>Jaymar Anasco</p> <p>IT / Technical Support</p> <p>APEXS, Incorporated</p>', NULL, NULL, NULL, '<p>IT &amp; Technical support</p>', 1, 0, 0, 0, 0, 0, 0, 25, 0, 'none', 'Letter', '{"def_assn_role":true,"browser_lang":"en_US","avatar":"oElEZx1inYZ92yptA5t9m"}', '{"user.create":1,"user.delete":1,"user.edit":1,"user.manage":1,"user.dir":1,"org.create":1,"org.delete":1,"org.edit":1,"faq.manage":1,"visibility.agents":1,"visibility.departments":1}', '2025-12-10 06:47:26', '2025-12-10 07:58:02', '2025-12-10 06:47:26', '2025-12-10 07:59:43'),
(3, 1, 2, 'jcacejo', 'James Curl', 'Acejo', '$2a$08$tVtnR9KSkQ4r9Jms/GEjTu3rQesSLq5kIQCbN0nb46wF2dAFBPAsa', NULL, 'jcacejo@apexsinc.com', '', NULL, '', '', NULL, NULL, NULL, NULL, 1, 0, 1, 0, 0, 0, 0, 0, 0, 'none', 'Letter', '{"def_assn_role":true}', '{"user.create":1,"user.delete":1,"user.edit":1,"user.manage":1,"user.dir":1,"org.create":1,"org.delete":1,"org.edit":1,"faq.manage":1,"visibility.agents":1,"visibility.departments":1}', '2025-12-10 07:56:17', NULL, '2025-12-10 07:56:17', '2025-12-10 07:56:17'),
(4, 1, 2, 'earanza', 'Eliakim', 'Aranza', '$2a$08$lKNSqv4shvvrVSuP3vBWteZ58/WCAquEJu5e0wrkb25ugdsj08xbq', NULL, 'earanza@apexsinc.com', '', NULL, '', '', NULL, NULL, NULL, NULL, 1, 0, 1, 0, 0, 0, 0, 0, 0, 'none', 'Letter', '{"def_assn_role":true}', '{"user.create":1,"user.delete":1,"user.edit":1,"user.manage":1,"user.dir":1,"org.create":1,"org.delete":1,"org.edit":1,"faq.manage":1,"visibility.agents":1,"visibility.departments":1}', '2025-12-10 07:57:31', NULL, '2025-12-10 07:57:31', '2025-12-10 07:57:31');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_staff_dept_access`
--

CREATE TABLE `ostqr_staff_dept_access` (
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`staff_id`,`dept_id`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_staff_dept_access`
--

INSERT INTO `ostqr_staff_dept_access` VALUES
(1, 2, 1, 1),
(1, 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_syslog`
--

CREATE TABLE `ostqr_syslog` (
  `log_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` enum('Debug','Warning','Error') NOT NULL,
  `title` varchar(255) NOT NULL,
  `log` text NOT NULL,
  `logger` varchar(64) NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_syslog`
--

INSERT INTO `ostqr_syslog` VALUES
(2, 'Warning', 'Invalid CSRF Token __CSRFToken__', 'Invalid CSRF token [] on https://support-apexsinc-com.apexvalue.com/', '', '65.87.7.112', '2025-12-10 15:31:51', '2025-12-10 15:31:51');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_task`
--

CREATE TABLE `ostqr_task` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL DEFAULT 0,
  `object_type` char(1) NOT NULL,
  `number` varchar(20) DEFAULT NULL,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `lock_id` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `duedate` datetime DEFAULT NULL,
  `closed` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dept_id` (`dept_id`),
  KEY `staff_id` (`staff_id`),
  KEY `team_id` (`team_id`),
  KEY `created` (`created`),
  KEY `object` (`object_id`,`object_type`),
  KEY `flags` (`flags`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_task__cdata`
--

CREATE TABLE `ostqr_task__cdata` (
  `task_id` int(11) unsigned NOT NULL DEFAULT 0,
  `title` mediumtext DEFAULT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_team`
--

CREATE TABLE `ostqr_team` (
  `team_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `name` varchar(125) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`team_id`),
  UNIQUE KEY `name` (`name`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_team`
--

INSERT INTO `ostqr_team` VALUES
(1, 0, 1, 'Level I Support', 'Tier 1 support, responsible for the initial iteraction with customers', '2025-12-10 05:54:55', '2025-12-10 05:54:55'),
(2, 0, 1, 'Level 2', NULL, '2025-12-10 06:48:11', '2025-12-10 06:48:11');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_team_member`
--

CREATE TABLE `ostqr_team_member` (
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`team_id`,`staff_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_thread`
--

CREATE TABLE `ostqr_thread` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) unsigned NOT NULL,
  `object_type` char(1) NOT NULL,
  `extra` text DEFAULT NULL,
  `lastresponse` datetime DEFAULT NULL,
  `lastmessage` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `object_type` (`object_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_thread`
--

INSERT INTO `ostqr_thread` VALUES
(5, 5, 'T', NULL, NULL, '2025-12-10 09:40:04', '2025-12-10 09:40:03');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_thread_collaborator`
--

CREATE TABLE `ostqr_thread_collaborator` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flags` int(10) unsigned NOT NULL DEFAULT 1,
  `thread_id` int(11) unsigned NOT NULL DEFAULT 0,
  `user_id` int(11) unsigned NOT NULL DEFAULT 0,
  `role` char(1) NOT NULL DEFAULT 'M',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `collab` (`thread_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_thread_entry`
--

CREATE TABLE `ostqr_thread_entry` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT 0,
  `thread_id` int(11) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(11) unsigned NOT NULL DEFAULT 0,
  `user_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` char(1) NOT NULL DEFAULT '',
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `poster` varchar(128) NOT NULL DEFAULT '',
  `editor` int(10) unsigned DEFAULT NULL,
  `editor_type` char(1) DEFAULT NULL,
  `source` varchar(32) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `body` text NOT NULL,
  `format` varchar(16) NOT NULL DEFAULT 'html',
  `ip_address` varchar(64) NOT NULL DEFAULT '',
  `extra` text DEFAULT NULL,
  `recipients` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `thread_id` (`thread_id`),
  KEY `staff_id` (`staff_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_thread_entry`
--

INSERT INTO `ostqr_thread_entry` VALUES
(8, 0, 5, 0, 3, 'M', 65, 'asdfasd fasdf', NULL, NULL, '', NULL, '<p>asdfasdfasdfasdfasd fasdf</p>', 'html', '180.190.23.94', NULL, NULL, '2025-12-10 09:40:04', '2025-12-10 09:40:04');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_thread_entry_email`
--

CREATE TABLE `ostqr_thread_entry_email` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `thread_entry_id` int(11) unsigned NOT NULL,
  `email_id` int(11) unsigned DEFAULT NULL,
  `mid` varchar(255) NOT NULL,
  `headers` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `thread_entry_id` (`thread_entry_id`),
  KEY `mid` (`mid`),
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_thread_entry_merge`
--

CREATE TABLE `ostqr_thread_entry_merge` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `thread_entry_id` int(11) unsigned NOT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `thread_entry_id` (`thread_entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_thread_event`
--

CREATE TABLE `ostqr_thread_event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) unsigned NOT NULL DEFAULT 0,
  `thread_type` char(1) NOT NULL DEFAULT '',
  `event_id` int(11) unsigned DEFAULT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `team_id` int(11) unsigned NOT NULL,
  `dept_id` int(11) unsigned NOT NULL,
  `topic_id` int(11) unsigned NOT NULL,
  `data` varchar(1024) DEFAULT NULL COMMENT 'Encoded differences',
  `username` varchar(128) NOT NULL DEFAULT 'SYSTEM',
  `uid` int(11) unsigned DEFAULT NULL,
  `uid_type` char(1) NOT NULL DEFAULT 'S',
  `annulled` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_state` (`thread_id`,`event_id`,`timestamp`),
  KEY `ticket_stats` (`timestamp`,`event_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_thread_event`
--

INSERT INTO `ostqr_thread_event` VALUES
(1, 0, 'T', 1, 0, 0, 1, 1, NULL, 'SYSTEM', 1, 'U', 0, '2025-12-10 05:54:55'),
(2, 0, 'T', 8, 0, 0, 1, 1, NULL, 'SYSTEM', NULL, 'S', 0, '2025-12-10 05:55:03'),
(3, 0, 'T', 2, 1, 0, 1, 1, '{"status":[2,"Resolved"]}', 'y0Tnc6zhZB51Dg', 1, 'S', 1, '2025-12-10 07:09:29'),
(4, 0, 'T', 2, 1, 0, 1, 1, '{"status":[3,"Closed"]}', 'y0Tnc6zhZB51Dg', 1, 'S', 1, '2025-12-10 07:10:11'),
(5, 0, 'T', 9, 1, 0, 1, 1, '{"fields":{"20":["osTicket Installed!","ticket system Installed!"],"22":[null,[false,null]]}}', 'y0Tnc6zhZB51Dg', 1, 'S', 0, '2025-12-10 07:11:28'),
(6, 0, 'T', 2, 1, 0, 1, 1, '{"status":[2,"Resolved"]}', 'y0Tnc6zhZB51Dg', 1, 'S', 0, '2025-12-10 07:11:42'),
(7, 0, 'T', 1, 0, 0, 1, 11, NULL, 'SYSTEM', 2, 'U', 0, '2025-12-10 07:15:52'),
(8, 0, 'T', 4, 2, 0, 1, 11, '{"claim":true}', 'janasco', 2, 'S', 0, '2025-12-10 08:00:59'),
(9, 0, 'T', 1, 0, 0, 3, 10, NULL, 'SYSTEM', 2, 'U', 0, '2025-12-10 09:05:52'),
(10, 0, 'T', 1, 0, 0, 1, 1, NULL, 'SYSTEM', 2, 'U', 0, '2025-12-10 09:23:04'),
(11, 2, 'T', 14, 2, 0, 1, 11, NULL, 'y0Tnc6zhZB51Dg', 1, 'S', 0, '2025-12-10 09:38:56'),
(12, 4, 'T', 14, 1, 0, 1, 1, NULL, 'y0Tnc6zhZB51Dg', 1, 'S', 0, '2025-12-10 09:38:56'),
(13, 3, 'T', 14, 1, 0, 3, 10, NULL, 'y0Tnc6zhZB51Dg', 1, 'S', 0, '2025-12-10 09:38:56'),
(14, 1, 'T', 14, 1, 0, 1, 1, NULL, 'y0Tnc6zhZB51Dg', 1, 'S', 0, '2025-12-10 09:39:26'),
(15, 5, 'T', 1, 0, 0, 3, 10, NULL, 'SYSTEM', 3, 'U', 0, '2025-12-10 09:40:04');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_thread_referral`
--

CREATE TABLE `ostqr_thread_referral` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) unsigned NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `object_type` char(1) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ref` (`object_id`,`object_type`,`thread_id`),
  KEY `thread_id` (`thread_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_ticket`
--

CREATE TABLE `ostqr_ticket` (
  `ticket_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_pid` int(11) unsigned DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT 0,
  `user_email_id` int(11) unsigned NOT NULL DEFAULT 0,
  `status_id` int(10) unsigned NOT NULL DEFAULT 0,
  `dept_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sla_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `staff_id` int(10) unsigned NOT NULL DEFAULT 0,
  `team_id` int(10) unsigned NOT NULL DEFAULT 0,
  `email_id` int(11) unsigned NOT NULL DEFAULT 0,
  `lock_id` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `ip_address` varchar(64) NOT NULL DEFAULT '',
  `source` enum('Web','Email','Phone','API','Other') NOT NULL DEFAULT 'Other',
  `source_extra` varchar(40) DEFAULT NULL,
  `isoverdue` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `isanswered` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `duedate` datetime DEFAULT NULL,
  `est_duedate` datetime DEFAULT NULL,
  `reopened` datetime DEFAULT NULL,
  `closed` datetime DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `user_id` (`user_id`),
  KEY `dept_id` (`dept_id`),
  KEY `staff_id` (`staff_id`),
  KEY `team_id` (`team_id`),
  KEY `status_id` (`status_id`),
  KEY `created` (`created`),
  KEY `closed` (`closed`),
  KEY `duedate` (`duedate`),
  KEY `topic_id` (`topic_id`),
  KEY `sla_id` (`sla_id`),
  KEY `ticket_pid` (`ticket_pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_ticket`
--

INSERT INTO `ostqr_ticket` VALUES
(5, NULL, '162664', 3, 0, 1, 3, 1, 10, 0, 0, 0, 0, 0, 0, '180.190.23.94', 'Web', NULL, 0, 0, NULL, '2025-12-12 09:00:00', NULL, NULL, '2025-12-10 09:40:04', '2025-12-10 09:40:03', '2025-12-10 09:40:04');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_ticket_priority`
--

CREATE TABLE `ostqr_ticket_priority` (
  `priority_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `priority` varchar(60) NOT NULL DEFAULT '',
  `priority_desc` varchar(30) NOT NULL DEFAULT '',
  `priority_color` varchar(7) NOT NULL DEFAULT '',
  `priority_urgency` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `ispublic` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`priority_id`),
  UNIQUE KEY `priority` (`priority`),
  KEY `priority_urgency` (`priority_urgency`),
  KEY `ispublic` (`ispublic`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_ticket_priority`
--

INSERT INTO `ostqr_ticket_priority` VALUES
(1, 'low', 'Low', '#DDFFDD', 4, 1),
(2, 'normal', 'Normal', '#FFFFF0', 3, 1),
(3, 'high', 'High', '#FEE7E7', 2, 1),
(4, 'emergency', 'Emergency', '#FEE7E7', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_ticket_status`
--

CREATE TABLE `ostqr_ticket_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `state` varchar(16) DEFAULT NULL,
  `mode` int(11) unsigned NOT NULL DEFAULT 0,
  `flags` int(11) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `properties` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_ticket_status`
--

INSERT INTO `ostqr_ticket_status` VALUES
(1, 'Open', 'open', 3, 0, 1, '{"description":"Open tickets."}', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(2, 'Resolved', 'closed', 1, 0, 2, '{"allowreopen":true,"reopenstatus":0,"description":"Resolved tickets"}', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(3, 'Closed', 'closed', 3, 0, 3, '{"allowreopen":true,"reopenstatus":0,"description":"Closed tickets. Tickets will still be accessible on client and staff panels."}', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(4, 'Archived', 'archived', 3, 0, 4, '{"description":"Tickets only adminstratively available but no longer accessible on ticket queues and client panel."}', '2025-12-10 05:54:55', '0000-00-00 00:00:00'),
(5, 'Deleted', 'deleted', 3, 0, 5, '{"description":"Tickets queued for deletion. Not accessible on ticket queues."}', '2025-12-10 05:54:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_ticket__cdata`
--

CREATE TABLE `ostqr_ticket__cdata` (
  `ticket_id` int(11) unsigned NOT NULL DEFAULT 0,
  `subject` mediumtext DEFAULT NULL,
  `priority` mediumtext DEFAULT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_ticket__cdata`
--

INSERT INTO `ostqr_ticket__cdata` VALUES
(5, 'asdfasdfasdf', '2');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_translation`
--

CREATE TABLE `ostqr_translation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `object_hash` char(16) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `type` enum('phrase','article','override') DEFAULT NULL,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `revision` int(11) unsigned DEFAULT NULL,
  `agent_id` int(10) unsigned NOT NULL DEFAULT 0,
  `lang` varchar(16) NOT NULL DEFAULT '',
  `text` mediumtext NOT NULL,
  `source_text` text DEFAULT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`lang`),
  KEY `object_hash` (`object_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_user`
--

CREATE TABLE `ostqr_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` int(10) unsigned NOT NULL,
  `default_email_id` int(10) NOT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(128) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `org_id` (`org_id`),
  KEY `default_email_id` (`default_email_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_user`
--

INSERT INTO `ostqr_user` VALUES
(3, 0, 3, 0, 'asdfasd fasdf', '2025-12-10 09:40:03', '2025-12-10 09:40:03');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_user_account`
--

CREATE TABLE `ostqr_user_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `status` int(11) unsigned NOT NULL DEFAULT 0,
  `timezone` varchar(64) DEFAULT NULL,
  `lang` varchar(16) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `passwd` varchar(128) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `backend` varchar(32) DEFAULT NULL,
  `extra` text DEFAULT NULL,
  `registered` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_user_email`
--

CREATE TABLE `ostqr_user_email` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`),
  KEY `user_email_lookup` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_user_email`
--

INSERT INTO `ostqr_user_email` VALUES
(3, 3, 0, 'it.apexsinc@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr_user__cdata`
--

CREATE TABLE `ostqr_user__cdata` (
  `user_id` int(11) unsigned NOT NULL DEFAULT 0,
  `email` mediumtext DEFAULT NULL,
  `name` mediumtext DEFAULT NULL,
  `phone` mediumtext DEFAULT NULL,
  `notes` mediumtext DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr_user__cdata`
--

INSERT INTO `ostqr_user__cdata` VALUES
(1, NULL, NULL, '', ''),
(2, NULL, NULL, '', ''),
(3, NULL, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ostqr__search`
--

CREATE TABLE `ostqr__search` (
  `object_type` varchar(8) NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `title` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  PRIMARY KEY (`object_type`,`object_id`),
  FULLTEXT KEY `search` (`title`,`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `ostqr__search`
--

INSERT INTO `ostqr__search` VALUES
('O', 1, 'APEXS', ''),
('U', 3, 'asdfasd fasdf', ' it.apexsinc@gmail.com\nit.apexsinc@gmail.com'),
('T', 5, '162664 asdfasdfasdf', 'asdfasdfasdf'),
('H', 8, '', 'asdfasdfasdfasdfasd fasdf');

-- --------------------------------------------------------

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
