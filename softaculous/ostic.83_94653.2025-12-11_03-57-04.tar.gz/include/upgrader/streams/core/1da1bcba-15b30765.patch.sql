/**
 * @version v1.7 RC2+
 * @signature 15b3076533123ff617801d89861136c8
 *
 * Transitional patch.
 *  
 */

-- Finished with patch
UPDATE `%TABLE_PREFIX%config`
    SET `schema_signature`='15b3076533123ff617801d89861136c8';
