<?php
header('Location: settings.php');
require('./settings.php');
?>
